# Shadow Rift roadmap

- V1.2 — World & Modes: delivered in this source package (four modes, six map themes, expanded menu, original SFX).
- V1.3 — Art & Animation: replace procedural combat shapes with a coherent HD sprite sheet; add directional locomotion, attack combo, hit, dash, skill, boss phase, and death animations.
- V1.4 — Progression: equipment inventory, item rarity, loot tables, character selection, and persistent chapter/dungeon unlocks.
- V2.0 — Content polish: story scenes, NPCs, handcrafted dungeon rooms, boss roster, balancing, accessibility, and device performance testing.
