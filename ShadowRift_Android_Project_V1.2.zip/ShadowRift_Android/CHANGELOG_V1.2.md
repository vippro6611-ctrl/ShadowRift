# Shadow Rift V1.2 — World & Modes Update

## Added
- Four distinct modes: Story (8 chapters and finale), Endless (uncapped waves), Dungeon (multi-room floors and boss rooms), and Boss Rush (one boss per round).
- Six selectable battlefields with different palettes and landmark silhouettes: Ruined Kingdom, Cursed Forest, Infernal Depths, Frozen Abyss, Ancient Temple, and Shadow Realm.
- Expanded main menu with dedicated mode selection, battlefield selection, armory, and settings panels.
- Mode name and wave are shown during combat; selected mode and battlefield are used when starting a run.
- Four original short sound effects (slash, magic, hit, reward) loaded through Android SoundPool. Sound toggle remains available in Settings.
- Saved Endless and Dungeon records.

## Existing systems retained
- Top-down arena combat, joystick, attack, skill, dash, boss health, XP upgrades, permanent armory upgrades, gold, and offline save data.

## Notes
- This is a playable feature update built on the existing Canvas prototype. Character art is still procedural geometry rather than a full HD sprite-sheet animation set; this update adds map identity and combat feedback, not hand-drawn animation frames.
- Build the debug APK with the included GitHub Actions workflow. The source package has not been compiled on a local Android SDK in this environment.
