# Shadow Rift Android — V1.2

Offline top-down action RPG prototype for Android (landscape, minSdk 23).

## V1.2 features
- Story, Endless, Dungeon, and Boss Rush modes with different wave rules.
- Six selectable battlefields with unique color themes and landmark layouts.
- Expanded menu, mode selection, map selection, armory, and settings.
- Original WAV combat sound effects played using Android SoundPool.
- Persistent gold, upgrades, records, and settings.

## Build APK
1. Upload the contents of this project folder to the root of your GitHub repository (keep `.github/workflows/build-apk.yml`).
2. Open **Actions** → **Build Shadow Rift V1.2 APK** → **Run workflow**.
3. When the workflow finishes, open its run and download the `ShadowRift-V1.2-APK` artifact.
4. Extract the artifact ZIP and install `app-debug.apk` on Android.

The workflow builds a debug APK. It is not a signed Play Store release.
