package com.shadowrift.game

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.AudioManager
import android.media.ToneGenerator
import android.media.SoundPool
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.*
import kotlin.random.Random

class MainActivity : Activity() {
    private lateinit var gameView: RiftGameView

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
             View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
             View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        gameView = RiftGameView(this)
        setContentView(gameView)
    }

    override fun onPause() {
        if (::gameView.isInitialized) gameView.pauseForLifecycle()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::gameView.isInitialized) gameView.resumeFrameClock()
    }

    override fun onDestroy() {
        gameView.releaseAudio()
        super.onDestroy()
    }
}

private data class Enemy(
    var x: Float, var y: Float, var hp: Float, var maxHp: Float,
    val kind: Int, val boss: Boolean = false,
    var flash: Float = 0f, var attackTimer: Float = 0f,
    var phaseTimer: Float = 0f
)

private data class Shot(var x: Float, var y: Float, var vx: Float, var vy: Float,
                        var damage: Float, var life: Float, val bossShot: Boolean = false)
private data class Particle(var x: Float, var y: Float, var vx: Float, var vy: Float,
                            var life: Float, val maxLife: Float, val color: Int, val radius: Float)
private data class Popup(var x: Float, var y: Float, val label: String, var life: Float,
                         val color: Int)
private data class Upgrade(val title: String, val detail: String, val apply: (RiftGameView) -> Unit)

private class RiftGameView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rng = Random(System.nanoTime())
    private val prefs = context.getSharedPreferences("shadow_rift_save", Context.MODE_PRIVATE)

    private var sw = 0f
    private var sh = 0f
    private var lastFrame = System.nanoTime()
    private var screen = Screen.MENU
    private enum class Screen { MENU, MODES, MAPS, PLAYING, PAUSED, LEVEL_UP, GAME_OVER, ARMORY, SETTINGS }
    private enum class GameMode(val title: String, val subtitle: String) {
        STORY("CỐT TRUYỆN", "8 chương • Boss cuối • Mở khóa tiến trình"),
        ENDLESS("VÔ TẬN", "Sóng quái không giới hạn • Kỷ lục cá nhân"),
        DUNGEON("HẦM NGỤC", "3 phòng mỗi tầng • Rương thưởng • Boss tầng"),
        BOSS_RUSH("SĂN BOSS", "Đối đầu liên tiếp • Chỉ có trùm")
    }

    // Permanent progress
    private var bankGold = 0
    private var bestWave = 1
    private var totalKills = 0
    private var permDamage = 0
    private var permVitality = 0
    private var permHaste = 0
    private var soundEnabled = true
    private var showDamageNumbers = true

    // Run state
    private var playerX = 0f
    private var playerY = 0f
    private var hp = 120f
    private var maxHp = 120f
    private var xp = 0
    private var level = 1
    private var runGold = 0
    private var wave = 1
    private var kills = 0
    private var damage = 24f
    private var attackCooldown = 0f
    private var attackPeriod = 0.42f
    private var skillCooldown = 0f
    private var skillPeriod = 8f
    private var dashCooldown = 0f
    private var dashPeriod = 4.2f
    private var invulnerable = 0f
    private var regenTimer = 0f
    private var spawnTimer = 1.2f
    private var spawnedThisWave = 0
    private var waveQuota = 5
    private var waveBanner = 2.5f
    private var banner = "THE RIFT AWAKENS"
    private var combo = 0
    private var comboTimer = 0f
    private var attackFxTimer = 0f
    private var attackFxAngle = 0f
    private var facingX = 1f
    private var facingY = 0f
    private var moveX = 0f
    private var moveY = 0f
    private var joyId = -1
    private var joyTouchX = 0f
    private var joyTouchY = 0f
    private var attackId = -1
    private var skillId = -1
    private var dashId = -1
    private var attackHeld = false
    private var skillQueued = false
    private var dashQueued = false
    private var dashTime = 0f
    private var dashVX = 0f
    private var dashVY = 0f
    private var showSettingsFromPause = false
    private var selectedMode = GameMode.STORY
    private var mapIndex = 0
    private var dungeonRoom = 1
    private var bestEndless = 0
    private var bestDungeon = 0
    private var menuPulse = 0f
    private val mapNames = listOf("TÀN TÍCH VƯƠNG QUỐC", "RỪNG NGUYỀN RỦA", "ĐỊA NGỤC ĐỎ", "VỰC BĂNG GIÁ", "ĐỀN CỔ", "CÕI HƯ VÔ")
    private val mapColors = intArrayOf(0xff28203b.toInt(), 0xff172c27.toInt(), 0xff351c25.toInt(), 0xff172b3d.toInt(), 0xff30291b.toInt(), 0xff211735.toInt())

    private val enemies = mutableListOf<Enemy>()
    private val shots = mutableListOf<Shot>()
    private val particles = mutableListOf<Particle>()
    private val popups = mutableListOf<Popup>()
    private val stars = ArrayList<FloatArray>()
    private var tone: ToneGenerator? = null
    private var soundPool: SoundPool? = null
    private var sfxSlash = 0
    private var sfxMagic = 0
    private var sfxHit = 0
    private var sfxReward = 0
    private var runWon = false
    private var runReward = 0

    private val purple = Color.rgb(164, 105, 255)
    private val pale = Color.rgb(232, 220, 255)
    private val bg = Color.rgb(8, 7, 17)
    private val goldColor = Color.rgb(255, 205, 102)
    private val red = Color.rgb(239, 76, 103)
    private val cyan = Color.rgb(93, 220, 235)

    init {
        isFocusable = true
        loadProgress()
        soundPool = SoundPool.Builder().setMaxStreams(8).build()
        sfxSlash = soundPool?.load(context, R.raw.sfx_slash, 1) ?: 0
        sfxMagic = soundPool?.load(context, R.raw.sfx_magic, 1) ?: 0
        sfxHit = soundPool?.load(context, R.raw.sfx_hit, 1) ?: 0
        sfxReward = soundPool?.load(context, R.raw.sfx_reward, 1) ?: 0
        repeat(90) { stars.add(floatArrayOf(rng.nextFloat(), rng.nextFloat(), rng.nextFloat() * 1.8f + .3f)) }
    }

    fun releaseAudio() {
        tone?.release()
        tone = null
        soundPool?.release()
        soundPool = null
    }

    fun pauseForLifecycle() {
        if (screen == Screen.PLAYING) screen = Screen.PAUSED
        clearTouchState()
        saveProgress()
    }

    fun resumeFrameClock() {
        lastFrame = System.nanoTime()
        postInvalidateOnAnimation()
    }

    private fun clearTouchState() {
        joyId = -1; attackId = -1; skillId = -1; dashId = -1
        moveX = 0f; moveY = 0f; attackHeld = false
        skillQueued = false; dashQueued = false
    }

    fun saveProgress() {
        prefs.edit()
            .putInt("bankGold", bankGold)
            .putInt("bestWave", bestWave)
            .putInt("totalKills", totalKills)
            .putInt("bestEndless", bestEndless)
            .putInt("bestDungeon", bestDungeon)
            .putInt("permDamage", permDamage)
            .putInt("permVitality", permVitality)
            .putInt("permHaste", permHaste)
            .putBoolean("sound", soundEnabled)
            .putBoolean("damageNumbers", showDamageNumbers)
            .commit()
    }

    private fun loadProgress() {
        bankGold = prefs.getInt("bankGold", 0).coerceAtLeast(0)
        bestWave = prefs.getInt("bestWave", 1).coerceAtLeast(1)
        totalKills = prefs.getInt("totalKills", 0).coerceAtLeast(0)
        bestEndless = prefs.getInt("bestEndless", 0).coerceAtLeast(0)
        bestDungeon = prefs.getInt("bestDungeon", 0).coerceAtLeast(0)
        permDamage = prefs.getInt("permDamage", 0).coerceIn(0, 4)
        permVitality = prefs.getInt("permVitality", 0).coerceIn(0, 4)
        permHaste = prefs.getInt("permHaste", 0).coerceIn(0, 4)
        soundEnabled = prefs.getBoolean("sound", true)
        showDamageNumbers = prefs.getBoolean("damageNumbers", true)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        sw = width.toFloat()
        sh = height.toFloat()
        if (sw <= 0f || sh <= 0f) return
        val now = System.nanoTime()
        val dt = ((now - lastFrame) / 1_000_000_000f).coerceIn(0f, .033f)
        lastFrame = now
        if (screen == Screen.PLAYING) update(dt)
        drawBackdrop(canvas)
        when (screen) {
            Screen.MENU -> drawMenu(canvas)
            Screen.MODES -> drawModes(canvas)
            Screen.MAPS -> drawMaps(canvas)
            Screen.PLAYING -> { drawArena(canvas); drawHud(canvas); drawControls(canvas); drawBanner(canvas) }
            Screen.PAUSED -> { drawArena(canvas); drawHud(canvas); drawOverlay(canvas); drawPause(canvas) }
            Screen.LEVEL_UP -> { drawArena(canvas); drawHud(canvas); drawLevelUp(canvas) }
            Screen.GAME_OVER -> { drawArena(canvas); drawHud(canvas); drawGameOver(canvas) }
            Screen.ARMORY -> drawArmory(canvas)
            Screen.SETTINGS -> drawSettings(canvas)
        }
        postInvalidateOnAnimation()
    }

    private fun drawBackdrop(c: Canvas) {
        c.drawColor(bg)
        paint.shader = LinearGradient(0f, 0f, sw, sh,
            intArrayOf(Color.rgb(10, 8, 25), Color.rgb(20, 10, 37), Color.rgb(6, 8, 19)),
            null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, sw, sh, paint)
        paint.shader = null
        for (s in stars) {
            paint.color = Color.argb((70 + 100 * s[2] / 2.1f).toInt().coerceIn(0, 170), 190, 170, 255)
            c.drawCircle(s[0] * sw, s[1] * sh, s[2], paint)
        }
        paint.shader = RadialGradient(sw * .5f, sh * .48f, min(sw, sh) * .65f,
            intArrayOf(0x302f1760, 0x00000000), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, sw, sh, paint)
        paint.shader = null
    }

    private fun drawMenu(c: Canvas) {
        menuPulse += .035f
        val cx = sw * .5f
        drawRiftSigil(c, cx, sh * .24f, min(sw, sh) * (.115f + .004f * sin(menuPulse)))
        text(c, "SHADOW", cx, sh * .105f, 17f, 0xffbda2ff.toInt(), Paint.Align.CENTER)
        text(c, "RIFT", cx, sh * .17f, 38f, pale, Paint.Align.CENTER)
        text(c, "CHRONICLES OF THE ABYSS", cx, sh * .385f, 10f, 0xffb7a9ca.toInt(), Paint.Align.CENTER)
        panel(c, sw * .28f, sh * .435f, sw * .72f, sh * .565f, 0xff7045bd.toInt(), 13f)
        text(c, "BẮT ĐẦU", cx, sh * .515f, 17f, Color.WHITE, Paint.Align.CENTER)
        val left = sw * .12f; val right = sw * .88f; val mid = sw * .5f
        smallButton(c, left, sh * .60f, mid - 7f, sh * .70f, "CHẾ ĐỘ GAME")
        smallButton(c, mid + 7f, sh * .60f, right, sh * .70f, "BẢN ĐỒ")
        smallButton(c, left, sh * .73f, mid - 7f, sh * .83f, "KHO TRANG BỊ")
        smallButton(c, mid + 7f, sh * .73f, right, sh * .83f, "CÀI ĐẶT")
        text(c, "VÀNG $bankGold   •   KỶ LỤC $bestWave   •   HẠ GỤC $totalKills", cx, sh * .91f, 10f, 0xffc2b4d7.toInt(), Paint.Align.CENTER)
        text(c, "OFFLINE ACTION RPG  •  V1.2", cx, sh * .96f, 9f, 0xff817495.toInt(), Paint.Align.CENTER)
    }

    private fun drawModes(c: Canvas) {
        text(c, "CHỌN CHẾ ĐỘ", sw / 2f, sh * .13f, 25f, pale, Paint.Align.CENTER)
        text(c, "Mỗi hành trình có luật chơi và phần thưởng riêng", sw / 2f, sh * .20f, 11f, 0xffb7a9ca.toInt(), Paint.Align.CENTER)
        val modes = GameMode.values()
        modes.forEachIndexed { i, mode ->
            val col = i % 2; val row = i / 2
            val l = if (col == 0) sw * .10f else sw * .515f
            val r = if (col == 0) sw * .485f else sw * .90f
            val t = sh * (.29f + row * .23f)
            panel(c, l, t, r, t + sh * .17f, if (selectedMode == mode) 0xff563786.toInt() else 0xff211932.toInt(), 12f)
            text(c, mode.title, (l + r) / 2f, t + 32f, 15f, pale, Paint.Align.CENTER)
            wrapText(c, mode.subtitle, (l + r) / 2f, t + 56f, 9f, 0xffc2b4d7.toInt(), r-l-20f)
        }
        smallButton(c, sw * .10f, sh * .80f, sw * .48f, sh * .90f, "ĐỔI BẢN ĐỒ")
        smallButton(c, sw * .52f, sh * .80f, sw * .90f, sh * .90f, "QUAY LẠI")
    }

    private fun drawMaps(c: Canvas) {
        text(c, "CHỌN CHIẾN TRƯỜNG", sw / 2f, sh * .13f, 24f, pale, Paint.Align.CENTER)
        mapNames.forEachIndexed { i, name ->
            val col = i % 3; val row = i / 3
            val l = sw * (.07f + col * .29f); val r = l + sw * .27f
            val t = sh * (.27f + row * .28f)
            panel(c, l, t, r, t + sh * .21f, if (mapIndex == i) 0xff563786.toInt() else mapColors[i], 11f)
            paint.color = mapColors[i]; c.drawCircle((l+r)/2f, t+sh*.075f, 19f, paint)
            text(c, "${i+1}", (l+r)/2f, t+sh*.085f, 16f, Color.WHITE, Paint.Align.CENTER)
            wrapText(c, name, (l+r)/2f, t+sh*.16f, 9f, pale, r-l-12f)
        }
        text(c, "BẢN ĐỒ ĐANG CHỌN: ${mapNames[mapIndex]}", sw/2f, sh*.83f, 11f, 0xffffd58b.toInt(), Paint.Align.CENTER)
        menuButton(c, "QUAY LẠI", sh * .91f)
    }

    private fun drawRiftSigil(c: Canvas, x: Float, y: Float, r: Float) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 2f
        paint.color = 0x887f4ad4.toInt()
        c.drawCircle(x, y, r, paint)
        c.drawCircle(x, y, r * .72f, paint)
        paint.color = 0x55c7a8ff
        c.drawCircle(x, y, r * .45f, paint)
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(x, y, r, intArrayOf(0x886b35c9.toInt(), 0x006b35c9), null, Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, paint)
        paint.shader = null
        paint.color = pale
        val path = android.graphics.Path()
        path.moveTo(x, y - r * .52f); path.lineTo(x + r * .16f, y - r * .05f)
        path.lineTo(x - r * .08f, y + r * .5f); path.lineTo(x - r * .02f, y + r * .08f)
        path.lineTo(x - r * .18f, y + r * .08f); path.close()
        c.drawPath(path, paint)
    }

    private fun drawArena(c: Canvas) {
        c.drawColor(mapColors[mapIndex])
        paint.color = when (mapIndex) { 1 -> 0xff20372f.toInt(); 2 -> 0xff4a202b.toInt(); 3 -> 0xff20394d.toInt(); 4 -> 0xff40351f.toInt(); 5 -> 0xff302044.toInt(); else -> 0xff19132b.toInt() }; paint.strokeWidth = 1f
        var x = 0f
        while (x < sw) { c.drawLine(x, 0f, x, sh, paint); x += 46f }
        var y = 0f
        while (y < sh) { c.drawLine(0f, y, sw, y, paint); y += 46f }
        // Distinct landmark silhouettes make each battlefield readable at a glance.
        val landmark = when (mapIndex) { 1 -> 0xff345044.toInt(); 2 -> 0xff6b3038.toInt(); 3 -> 0xff34566b.toInt(); 4 -> 0xff665332.toInt(); 5 -> 0xff50386f.toInt(); else -> 0xff39304f.toInt() }
        paint.color = landmark
        for (i in 0..4) {
            val ox = sw * (.16f + (i % 3) * .34f)
            val oy = sh * (.25f + (i / 3) * .48f)
            if (mapIndex == 1 || mapIndex == 4) c.drawRoundRect(ox-15f, oy-20f, ox+15f, oy+20f, 6f, 6f, paint)
            else c.drawCircle(ox, oy, 13f + (i%2)*5f, paint)
            paint.color = 0x445f4b78
            c.drawCircle(ox, oy, 22f, paint)
            paint.color = landmark
        }
        paint.shader = RadialGradient(sw * .5f, sh * .5f, min(sw, sh) * .58f,
            intArrayOf(0x302e1659, 0x00100820), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, sw, sh, paint); paint.shader = null

        // Rift ring in arena center
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = 0x223f2b68
        c.drawCircle(sw * .5f, sh * .52f, min(sw, sh) * .24f, paint)
        paint.color = 0x183c2c63; c.drawCircle(sw * .5f, sh * .52f, min(sw, sh) * .34f, paint)
        paint.style = Paint.Style.FILL

        enemies.forEach { drawEnemy(c, it) }
        shots.forEach {
            paint.color = if (it.bossShot) 0xffff557c.toInt() else 0xffc48cff.toInt()
            c.drawCircle(it.x, it.y, if (it.bossShot) 7f else 4f, paint)
            paint.color = if (it.bossShot) 0x66ff557c else 0x668f62ff
            c.drawCircle(it.x, it.y, if (it.bossShot) 13f else 8f, paint)
        }
        particles.forEach {
            paint.color = it.color
            paint.alpha = (255 * (it.life / it.maxLife).coerceIn(0f, 1f)).toInt()
            c.drawCircle(it.x, it.y, it.radius * (it.life / it.maxLife).coerceIn(.15f, 1f), paint)
            paint.alpha = 255
        }
        popups.forEach {
            paint.color = Color.argb((255 * (it.life / .8f).coerceIn(0f, 1f)).toInt(), Color.red(it.color), Color.green(it.color), Color.blue(it.color))
            paint.textSize = 13f; paint.typeface = Typeface.DEFAULT_BOLD; paint.textAlign = Paint.Align.CENTER
            c.drawText(it.label, it.x, it.y, paint)
        }
        drawPlayer(c)
    }

    private fun drawEnemy(c: Canvas, e: Enemy) {
        val r = when { e.boss -> 31f; e.kind == 2 -> 20f; e.kind == 1 -> 12f; e.kind == 3 -> 14f; else -> 15f }
        val body = when { e.boss -> 0xff9e285f.toInt(); e.kind == 1 -> 0xffed6378.toInt(); e.kind == 2 -> 0xff76506f.toInt(); e.kind == 3 -> 0xff8b65cf.toInt(); else -> 0xffb83e60.toInt() }
        // Ground shadow and soft aura
        paint.color = 0x77000000
        c.drawOval(e.x - r * 1.05f, e.y + r * .48f, e.x + r * 1.05f, e.y + r * .88f, paint)
        paint.shader = RadialGradient(e.x, e.y, r * 1.8f,
            intArrayOf(if (e.boss) 0x667c174d else 0x445b245e, 0x00000000), null, Shader.TileMode.CLAMP)
        c.drawCircle(e.x, e.y, r * 1.8f, paint); paint.shader = null
        paint.color = if (e.flash > 0f) Color.WHITE else body
        when {
            e.boss -> {
                val path = android.graphics.Path()
                path.moveTo(e.x, e.y - r * 1.25f)
                path.lineTo(e.x + r * .88f, e.y - r * .42f)
                path.lineTo(e.x + r * .78f, e.y + r * .62f)
                path.lineTo(e.x, e.y + r)
                path.lineTo(e.x - r * .78f, e.y + r * .62f)
                path.lineTo(e.x - r * .88f, e.y - r * .42f)
                path.close(); c.drawPath(path, paint)
                paint.color = 0xffffa3d0.toInt(); paint.strokeWidth = 3f
                c.drawLine(e.x - r * .7f, e.y - r * .35f, e.x - r * 1.15f, e.y - r * 1.05f, paint)
                c.drawLine(e.x + r * .7f, e.y - r * .35f, e.x + r * 1.15f, e.y - r * 1.05f, paint)
            }
            e.kind == 1 -> {
                val path = android.graphics.Path()
                path.moveTo(e.x, e.y - r * 1.35f); path.lineTo(e.x + r, e.y)
                path.lineTo(e.x, e.y + r * 1.2f); path.lineTo(e.x - r, e.y); path.close()
                c.drawPath(path, paint)
            }
            e.kind == 2 -> {
                val path = android.graphics.Path()
                for (i in 0..5) {
                    val a = (PI / 3.0 * i - PI / 6.0).toFloat()
                    val px = e.x + cos(a) * r; val py = e.y + sin(a) * r
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close(); c.drawPath(path, paint)
                paint.color = 0xffc9a4c7.toInt(); paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f
                c.drawCircle(e.x, e.y, r * .63f, paint); paint.style = Paint.Style.FILL
            }
            e.kind == 3 -> {
                c.drawCircle(e.x, e.y, r, paint)
                paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.5f; paint.color = 0xffd5baff.toInt()
                c.drawCircle(e.x, e.y, r + 5f, paint); paint.style = Paint.Style.FILL
                paint.color = 0xffd5baff.toInt(); c.drawCircle(e.x, e.y, 3.5f, paint)
            }
            else -> {
                c.drawCircle(e.x, e.y, r, paint)
                paint.color = 0xff6d203f.toInt()
                c.drawCircle(e.x - r * .85f, e.y + r * .1f, r * .32f, paint)
                c.drawCircle(e.x + r * .85f, e.y + r * .1f, r * .32f, paint)
            }
        }
        paint.color = 0xffffd7e6.toInt()
        c.drawCircle(e.x - r * .28f, e.y - r * .12f, max(2f, r * .12f), paint)
        c.drawCircle(e.x + r * .28f, e.y - r * .12f, max(2f, r * .12f), paint)
        if (e.boss || e.hp < e.maxHp) {
            val bw = if (e.boss) 82f else 38f
            val by = e.y - r - 12f
            panel(c, e.x - bw / 2, by, e.x + bw / 2, by + 6f, 0xff241521.toInt(), 3f)
            paint.color = if (e.boss) red else 0xffff7188.toInt()
            c.drawRoundRect(e.x - bw / 2, by, e.x - bw / 2 + bw * (e.hp / e.maxHp).coerceIn(0f, 1f), by + 6f, 3f, 3f, paint)
        }
        if (e.boss && e.hp / e.maxHp < .5f) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 2.5f; paint.color = 0x99ff4778.toInt()
            c.drawCircle(e.x, e.y, r + 9f + sin(e.phaseTimer * 5f) * 3f, paint)
            paint.style = Paint.Style.FILL
        }
    }

    private fun drawPlayer(c: Canvas) {
        if (invulnerable > 0f && (invulnerable * 18).toInt() % 2 == 0) return
        paint.color = 0x88000000.toInt()
        c.drawOval(playerX - 20f, playerY + 12f, playerX + 20f, playerY + 23f, paint)
        paint.shader = RadialGradient(playerX, playerY, 34f,
            intArrayOf(0x997e5cff.toInt(), 0x007e5cff), null, Shader.TileMode.CLAMP)
        c.drawCircle(playerX, playerY, 34f, paint); paint.shader = null
        // Cloak silhouette
        val cloak = android.graphics.Path()
        cloak.moveTo(playerX, playerY - 18f)
        cloak.lineTo(playerX + 17f, playerY + 5f)
        cloak.lineTo(playerX + 11f, playerY + 19f)
        cloak.lineTo(playerX, playerY + 14f)
        cloak.lineTo(playerX - 11f, playerY + 19f)
        cloak.lineTo(playerX - 17f, playerY + 5f)
        cloak.close()
        paint.color = if (dashTime > 0f) 0xff7ce7ff.toInt() else 0xff493276.toInt()
        c.drawPath(cloak, paint)
        paint.color = 0xffa98aff.toInt()
        c.drawCircle(playerX, playerY - 5f, 12f, paint)
        paint.color = 0xffe8dcff.toInt()
        c.drawCircle(playerX + facingX * 5f, playerY - 8f + facingY * 5f, 4.5f, paint)
        // Weapon points in the facing direction
        paint.color = 0xffd9d1ff.toInt(); paint.strokeWidth = 4f
        paint.strokeCap = Paint.Cap.ROUND
        c.drawLine(playerX + facingX * 8f, playerY + facingY * 8f,
            playerX + facingX * 29f, playerY + facingY * 29f, paint)
        paint.strokeWidth = 1f; paint.strokeCap = Paint.Cap.BUTT
        if (attackFxTimer > 0f) {
            val alpha = (220f * (attackFxTimer / .18f).coerceIn(0f, 1f)).toInt()
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 5f
            paint.color = Color.argb(alpha, 205, 174, 255)
            val rect = RectF(playerX - 48f, playerY - 48f, playerX + 48f, playerY + 48f)
            c.drawArc(rect, attackFxAngle - 48f, 96f, false, paint)
            paint.style = Paint.Style.FILL
        }
        if (dashTime > 0f) {
            paint.style = Paint.Style.STROKE; paint.strokeWidth = 3f; paint.color = 0x997de8ff.toInt()
            c.drawCircle(playerX, playerY, 27f, paint); paint.style = Paint.Style.FILL
        }
    }

    private fun drawHud(c: Canvas) {
        panel(c, 12f, 10f, 214f, 82f, 0xdd110d20.toInt())
        text(c, "SHADOW RIFT", 22f, 29f, 15f, pale)
        text(c, "${selectedMode.title} • ĐỢT $wave", 22f, 47f, 10f, 0xffc9b9e6.toInt())
        bar(c, 22f, 56f, 135f, 8f, hp, maxHp, red)
        text(c, "${hp.toInt()}/${maxHp.toInt()} HP", 164f, 64f, 9f, Color.WHITE)
        bar(c, 22f, 70f, 135f, 5f, xp.toFloat(), (level * 55).toFloat(), purple)
        text(c, "VÀNG $runGold", 22f, 94f, 10f, goldColor)

        panel(c, sw - 104f, 10f, sw - 12f, 48f, 0xdd110d20.toInt())
        text(c, "HẠ GỤC", sw - 58f, 25f, 9f, 0xffb9a9d0.toInt(), Paint.Align.CENTER)
        text(c, "$kills", sw - 58f, 41f, 15f, Color.WHITE, Paint.Align.CENTER)
        panel(c, sw - 48f, 58f, sw - 12f, 92f, 0xdd211932.toInt(), 8f)
        text(c, "Ⅱ", sw - 30f, 81f, 18f, Color.WHITE, Paint.Align.CENTER)

        val boss = enemies.firstOrNull { it.boss }
        if (boss != null) {
            val bw = min(sw * .42f, 310f)
            panel(c, (sw - bw) / 2f, 12f, (sw + bw) / 2f, 33f, 0xdd110d20.toInt())
            text(c, "RIFT WARDEN", sw / 2f, 23f, 9f, pale, Paint.Align.CENTER)
            bar(c, (sw - bw) / 2f + 8f, 27f, bw - 16f, 6f, boss.hp, boss.maxHp, red)
        }
    }

    private fun drawControls(c: Canvas) {
        val cx = 88f; val cy = sh - 88f
        paint.color = 0x553e355b; c.drawCircle(cx, cy, 55f, paint)
        paint.color = 0x998e7bb6.toInt()
        val knobDx = if (joyId >= 0) joyTouchX - cx else 0f
        val knobDy = if (joyId >= 0) joyTouchY - cy else 0f
        val knobLen = hypot(knobDx, knobDy).coerceAtLeast(1f)
        val knobScale = min(1f, 32f / knobLen)
        c.drawCircle(cx + knobDx * knobScale, cy + knobDy * knobScale, 23f, paint)
        actionButton(c, sw - 76f, sh - 78f, 39f, "ĐÁNH", 0xffa44be0.toInt(), attackCooldown / attackPeriod)
        actionButton(c, sw - 165f, sh - 62f, 31f, "NOVA", 0xff6845c7.toInt(), skillCooldown / skillPeriod)
        actionButton(c, sw - 246f, sh - 54f, 27f, "LƯỚT", 0xff397fae.toInt(), dashCooldown / dashPeriod)
        text(c, "CD ${skillCooldown.toInt()}s", sw - 165f, sh - 19f, 9f, Color.WHITE, Paint.Align.CENTER)
    }

    private fun actionButton(c: Canvas, x: Float, y: Float, r: Float, label: String, color: Int, cooldown: Float) {
        paint.color = 0xaa090711.toInt(); c.drawCircle(x, y, r + 5f, paint)
        paint.color = color; c.drawCircle(x, y, r, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 2f; paint.color = 0xffe8dcff.toInt()
        c.drawCircle(x, y, r, paint); paint.style = Paint.Style.FILL
        if (cooldown > 0f) {
            paint.color = 0x99090711.toInt()
            c.drawArc(x - r, y - r, x + r, y + r, -90f, 360f * cooldown.coerceIn(0f, 1f), true, paint)
        }
        text(c, label, x, y + 4f, if (label.length > 4) 9f else 11f, Color.WHITE, Paint.Align.CENTER)
    }

    private fun drawBanner(c: Canvas) {
        if (waveBanner <= 0f) return
        val alpha = (255 * min(1f, waveBanner)).toInt().coerceIn(0, 255)
        paint.color = Color.argb((alpha * .75f).toInt(), 12, 8, 24)
        c.drawRoundRect(sw * .3f, sh * .18f, sw * .7f, sh * .27f, 12f, 12f, paint)
        paint.color = Color.argb(alpha, 225, 208, 255)
        paint.textSize = 20f; paint.typeface = Typeface.DEFAULT_BOLD; paint.textAlign = Paint.Align.CENTER
        c.drawText(banner, sw * .5f, sh * .235f, paint)
    }

    private fun drawOverlay(c: Canvas) {
        paint.color = 0xbb070510.toInt()
        c.drawRect(0f, 0f, sw, sh, paint)
    }

    private fun drawPause(c: Canvas) {
        text(c, "TẠM DỪNG", sw / 2f, sh * .31f, 30f, pale, Paint.Align.CENTER)
        menuButton(c, "TIẾP TỤC", sh * .46f)
        menuButton(c, "CÀI ĐẶT", sh * .59f)
        menuButton(c, "VỀ MENU", sh * .72f)
    }

    private fun drawLevelUp(c: Canvas) {
        paint.color = 0xdd080611.toInt(); c.drawRect(0f, 0f, sw, sh, paint)
        text(c, "THỨC TỈNH SỨC MẠNH", sw / 2f, sh * .24f, 24f, pale, Paint.Align.CENTER)
        text(c, "CẤP ĐỘ $level", sw / 2f, sh * .31f, 13f, goldColor, Paint.Align.CENTER)
        val cards = upgradeCards()
        for (i in cards.indices) {
            val cx = sw * (0.22f + i * .28f)
            panel(c, cx - 92f, sh * .40f, cx + 92f, sh * .70f, if (i == 1) 0xff54358e.toInt() else 0xff211932.toInt())
            text(c, cards[i].title, cx, sh * .49f, 14f, pale, Paint.Align.CENTER)
            wrapText(c, cards[i].detail, cx, sh * .55f, 12f, 0xffc4b7d8.toInt(), 150f)
            text(c, "CHỌN", cx, sh * .66f, 11f, goldColor, Paint.Align.CENTER)
        }
    }

    private fun drawGameOver(c: Canvas) {
        paint.color = 0xdd080611.toInt(); c.drawRect(0f, 0f, sw, sh, paint)
        text(c, if (runWon) "HÀNH TRÌNH HOÀN TẤT" else "BẠN ĐÃ GỤC NGÃ", sw / 2f, sh * .29f, 27f, if (runWon) goldColor else red, Paint.Align.CENTER)
        text(c, "${selectedMode.title}  •  Đợt $wave  •  Hạ $kills quái", sw / 2f, sh * .39f, 13f, Color.WHITE, Paint.Align.CENTER)
        text(c, "Nhận được $runReward vàng", sw / 2f, sh * .45f, 13f, goldColor, Paint.Align.CENTER)
        menuButton(c, "CHƠI LẠI", sh * .59f)
        menuButton(c, "VỀ MENU", sh * .72f)
    }

    private fun drawArmory(c: Canvas) {
        text(c, "KHO TRANG BỊ", sw / 2f, 45f, 25f, pale, Paint.Align.CENTER)
        text(c, "VÀNG: $bankGold", sw / 2f, 72f, 13f, goldColor, Paint.Align.CENTER)
        val rows = listOf(
            Triple("VŨ KHÍ • LƯỠI KIẾM RIFT", "Sát thương +5  •  Bậc ${tierName(permDamage)}", 100 * (permDamage + 1)),
            Triple("GIÁP • GIÁP HẮC ÁM", "Máu tối đa +15  •  Bậc ${tierName(permVitality)}", 120 * (permVitality + 1)),
            Triple("DI VẬT • LÕI TINH THẠCH", "Tốc đánh +4%  •  Bậc ${tierName(permHaste)}", 150 * (permHaste + 1))
        )
        rows.forEachIndexed { i, row ->
            val top = sh * (.20f + i * .19f)
            panel(c, sw * .12f, top, sw * .88f, top + 82f, 0xff211932.toInt())
            text(c, row.first, sw * .16f, top + 27f, 13f, pale)
            text(c, row.second, sw * .16f, top + 49f, 10f, 0xffc2b4d7.toInt())
            smallButton(c, sw * .68f, top + 17f, sw * .84f, top + 64f, "${row.third} G")
        }
        menuButton(c, "QUAY LẠI", sh * .88f)
    }

    private fun drawSettings(c: Canvas) {
        text(c, "CÀI ĐẶT", sw / 2f, sh * .25f, 28f, pale, Paint.Align.CENTER)
        menuButton(c, "ÂM THANH: ${if (soundEnabled) "BẬT" else "TẮT"}", sh * .43f)
        menuButton(c, "SỐ SÁT THƯƠNG: ${if (showDamageNumbers) "BẬT" else "TẮT"}", sh * .57f)
        menuButton(c, "QUAY LẠI", sh * .73f)
        text(c, "Shadow Rift V1.1 • Offline", sw / 2f, sh * .88f, 11f, 0xff9486aa.toInt(), Paint.Align.CENTER)
    }

    private fun menuButton(c: Canvas, label: String, cy: Float) {
        panel(c, sw * .34f, cy - 25f, sw * .66f, cy + 25f, 0xff33244d.toInt())
        text(c, label, sw * .5f, cy + 5f, 15f, Color.WHITE, Paint.Align.CENTER)
    }

    private fun smallButton(c: Canvas, l: Float, t: Float, r: Float, b: Float, label: String) {
        panel(c, l, t, r, b, 0xff3b2a58.toInt())
        text(c, label, (l + r) / 2f, (t + b) / 2f + 4f, 10f, Color.WHITE, Paint.Align.CENTER)
    }

    private fun panel(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int, radius: Float = 10f) {
        paint.color = 0x88000000.toInt()
        c.drawRoundRect(l + 2f, t + 3f, r + 2f, b + 3f, radius, radius, paint)
        paint.color = color
        c.drawRoundRect(l, t, r, b, radius, radius, paint)
        paint.style = Paint.Style.STROKE; paint.strokeWidth = 1f; paint.color = 0x557f68a8
        c.drawRoundRect(l, t, r, b, radius, radius, paint); paint.style = Paint.Style.FILL
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int,
                     align: Paint.Align = Paint.Align.LEFT) {
        paint.color = color; paint.textSize = size; paint.typeface = Typeface.DEFAULT_BOLD; paint.textAlign = align
        c.drawText(s, x, y, paint)
    }

    private fun wrapText(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int, maxWidth: Float) {
        paint.textSize = size; paint.typeface = Typeface.DEFAULT; paint.textAlign = Paint.Align.CENTER
        val words = value.split(" ")
        var line = ""; var yy = y
        for (word in words) {
            val test = if (line.isEmpty()) word else "$line $word"
            if (paint.measureText(test) > maxWidth && line.isNotEmpty()) {
                text(c, line, x, yy, size, color, Paint.Align.CENTER); line = word; yy += size + 4f
            } else line = test
        }
        if (line.isNotEmpty()) text(c, line, x, yy, size, color, Paint.Align.CENTER)
    }

    private fun bar(c: Canvas, x: Float, y: Float, width: Float, height: Float,
                    value: Float, max: Float, color: Int) {
        paint.color = 0xff30283e.toInt()
        c.drawRoundRect(x, y, x + width, y + height, 5f, 5f, paint)
        paint.color = color
        c.drawRoundRect(x, y, x + width * (value / max.coerceAtLeast(1f)).coerceIn(0f, 1f), y + height, 5f, 5f, paint)
    }

    private fun update(dt: Float) {
        attackCooldown = (attackCooldown - dt).coerceAtLeast(0f)
        attackFxTimer = (attackFxTimer - dt).coerceAtLeast(0f)
        skillCooldown = (skillCooldown - dt).coerceAtLeast(0f)
        dashCooldown = (dashCooldown - dt).coerceAtLeast(0f)
        invulnerable = (invulnerable - dt).coerceAtLeast(0f)
        dashTime = (dashTime - dt).coerceAtLeast(0f)
        waveBanner = (waveBanner - dt).coerceAtLeast(0f)
        comboTimer = (comboTimer - dt).coerceAtLeast(0f)
        if (comboTimer <= 0f) combo = 0

        if (dashTime > 0f) {
            playerX += dashVX * 620f * dt
            playerY += dashVY * 620f * dt
        } else {
            val len = hypot(moveX, moveY).coerceAtLeast(1f)
            val speed = (235f + permHaste * 2f)
            playerX += moveX * speed * dt
            playerY += moveY * speed * dt
        }
        playerX = playerX.coerceIn(25f, sw - 25f)
        playerY = playerY.coerceIn(35f, sh - 28f)
        if (abs(moveX) + abs(moveY) > .1f) {
            val d = hypot(moveX, moveY).coerceAtLeast(.01f)
            facingX = moveX / d; facingY = moveY / d
        }

        if (attackHeld && attackCooldown <= 0f) performAttack()
        if (skillQueued) { skillQueued = false; performSkill() }
        if (dashQueued) { dashQueued = false; performDash() }

        spawnTimer -= dt
        if (spawnedThisWave < waveQuota && spawnTimer <= 0f && enemies.size < 14) {
            spawnEnemy()
            spawnedThisWave++
            spawnTimer = max(.45f, 1.45f - wave * .025f)
        }
        if (spawnedThisWave >= waveQuota && enemies.isEmpty()) {
            if (selectedMode == GameMode.STORY && wave >= 8) {
                runReward = runGold + 100; bankGold += runReward; runGold = 0; runWon = true; saveProgress(); screen = Screen.GAME_OVER; banner = "CỐT TRUYỆN HOÀN TẤT"; return
            }
            if (selectedMode == GameMode.DUNGEON) {
                dungeonRoom++
                if (dungeonRoom > 3) { dungeonRoom = 1; bestDungeon = max(bestDungeon, wave / 3); runGold += 35 }
            }
            wave++
            bestWave = max(bestWave, wave)
            if (selectedMode == GameMode.ENDLESS) bestEndless = max(bestEndless, wave)
            spawnedThisWave = 0
            waveQuota = when (selectedMode) {
                GameMode.STORY -> 5 + min(8, wave)
                GameMode.ENDLESS -> 5 + min(18, wave * 2)
                GameMode.DUNGEON -> if (dungeonRoom == 3) 1 else 4 + wave
                GameMode.BOSS_RUSH -> 1
            }
            spawnTimer = 2.2f
            waveBanner = 2.5f
            banner = when (selectedMode) {
                GameMode.STORY -> if (wave % 4 == 0) "CHƯƠNG $wave • TRÙM XUẤT HIỆN" else "CHƯƠNG $wave"
                GameMode.DUNGEON -> "TẦNG ${((wave - 1) / 3) + 1} • PHÒNG $dungeonRoom"
                GameMode.BOSS_RUSH -> "TRẬN ĐẤU BOSS $wave"
                GameMode.ENDLESS -> if (wave % 5 == 0) "THE RIFT WARDEN APPROACHES" else "SÓNG VÔ TẬN $wave"
            }
            saveProgress()
        }

        updateEnemies(dt)
        updateShots(dt)
        updateEffects(dt)
        regenTimer += dt
        if (regenTimer >= 5f) {
            regenTimer = 0f
            if (hp > 0f && hp < maxHp) hp = min(maxHp, hp + 1.5f)
        }
        if (hp <= 0f) {
            hp = 0f
            runReward = runGold
            bankGold += runGold
            bestWave = max(bestWave, wave)
            saveProgress()
            screen = Screen.GAME_OVER
        }
    }

    private fun spawnEnemy() {
        val boss = when (selectedMode) {
            GameMode.BOSS_RUSH -> spawnedThisWave == 0
            GameMode.DUNGEON -> dungeonRoom == 3 && spawnedThisWave == 0
            GameMode.STORY -> wave % 4 == 0 && spawnedThisWave == 0
            GameMode.ENDLESS -> wave % 5 == 0 && spawnedThisWave == 0
        }
        val edge = rng.nextInt(4)
        val x = when (edge) { 0 -> 20f; 1 -> sw - 20f; else -> rng.nextFloat() * sw }
        val y = when (edge) { 2 -> 25f; 3 -> sh - 20f; else -> 35f + rng.nextFloat() * (sh - 70f) }
        val kind = if (boss) 4 else when {
            wave >= 4 && rng.nextFloat() < .18f -> 3
            wave >= 3 && rng.nextFloat() < .22f -> 2
            rng.nextFloat() < .22f -> 1
            else -> 0
        }
        val base = 38f + wave * 7f
        val max = when {
            boss -> 650f + wave * 70f
            kind == 2 -> base * 2.5f
            kind == 3 -> base * 1.15f
            kind == 1 -> base * .72f
            else -> base
        }
        enemies.add(Enemy(x, y, max, max, kind, boss, attackTimer = rng.nextFloat() * 1.5f))
        if (boss) { banner = "THE RIFT WARDEN"; waveBanner = 2.5f }
    }

    private fun performAttack() {
        attackCooldown = attackPeriod
        playTone(ToneGenerator.TONE_PROP_ACK)
        val target = enemies.minByOrNull { hypot(it.x - playerX, it.y - playerY) }
        if (target != null) {
            val dx = target.x - playerX; val dy = target.y - playerY
            val d = hypot(dx, dy)
            if (d < 145f) {
                facingX = dx / d.coerceAtLeast(1f); facingY = dy / d.coerceAtLeast(1f)
                attackFxAngle = Math.toDegrees(atan2(facingY.toDouble(), facingX.toDouble())).toFloat()
                attackFxTimer = .18f
                combo = if (comboTimer > 0f) (combo + 1).coerceAtMost(4) else 1
                comboTimer = 1.1f
                val dealt = damage * (1f + (combo - 1) * .13f)
                target.hp -= dealt
                target.flash = .12f
                if (showDamageNumbers) popups.add(Popup(target.x, target.y - 20f, dealt.toInt().toString(), .8f, goldColor))
                burst(target.x, target.y, 5, 0xffb78aff.toInt())
            } else combo = 0
        }
    }

    private fun performSkill() {
        if (skillCooldown > 0f) return
        skillCooldown = skillPeriod
        playTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD)
        val radius = 205f
        enemies.forEach { e ->
            if (hypot(e.x - playerX, e.y - playerY) < radius) {
                val dealt = if (e.boss) damage * 3.5f else damage * 4.5f
                e.hp -= dealt; e.flash = .22f
                if (showDamageNumbers) popups.add(Popup(e.x, e.y - 25f, dealt.toInt().toString(), .8f, cyan))
            }
        }
        repeat(38) {
            val a = rng.nextFloat() * PI.toFloat() * 2f
            val r = rng.nextFloat() * radius
            particles.add(Particle(playerX + cos(a) * r, playerY + sin(a) * r,
                cos(a) * rng.nextFloat() * 100f, sin(a) * rng.nextFloat() * 100f,
                .55f, .55f, if (it % 3 == 0) cyan else purple, rng.nextFloat() * 5f + 2f))
        }
        banner = "SHADOW NOVA!"
        waveBanner = 1.1f
    }

    private fun performDash() {
        if (dashCooldown > 0f) return
        dashCooldown = dashPeriod
        playTone(ToneGenerator.TONE_PROP_BEEP2)
        val len = hypot(moveX, moveY)
        if (len > .1f) { dashVX = moveX / len; dashVY = moveY / len }
        else { dashVX = facingX; dashVY = facingY }
        dashTime = .20f
        invulnerable = .38f
        burst(playerX, playerY, 16, cyan)
    }

    private fun updateEnemies(dt: Float) {
        val iterator = enemies.iterator()
        while (iterator.hasNext()) {
            val e = iterator.next()
            e.flash = (e.flash - dt).coerceAtLeast(0f)
            e.attackTimer -= dt
            e.phaseTimer += dt
            val dx = playerX - e.x; val dy = playerY - e.y
            val dist = hypot(dx, dy).coerceAtLeast(1f)
            if (e.boss) {
                val speed = if (e.hp / e.maxHp < .5f) 75f else 48f
                if (dist > 75f) { e.x += dx / dist * speed * dt; e.y += dy / dist * speed * dt }
                if (e.attackTimer <= 0f) {
                    e.attackTimer = if (e.hp / e.maxHp < .5f) 1.15f else 1.8f
                    val count = if (e.hp / e.maxHp < .5f) 10 else 6
                    repeat(count) { i ->
                        val a = (PI * 2.0 * i / count).toFloat()
                        shots.add(Shot(e.x, e.y, cos(a) * 145f, sin(a) * 145f, 14f, 3.5f, true))
                    }
                }
                if (dist < 42f && invulnerable <= 0f) damagePlayer(20f * dt)
            } else if (e.kind == 3) {
                if (dist > 205f) { e.x += dx / dist * 45f * dt; e.y += dy / dist * 45f * dt }
                if (dist < 145f) { e.x -= dx / dist * 35f * dt; e.y -= dy / dist * 35f * dt }
                if (e.attackTimer <= 0f) {
                    e.attackTimer = 2.1f
                    val vx = dx / dist * 125f; val vy = dy / dist * 125f
                    shots.add(Shot(e.x, e.y, vx, vy, 9f, 3f))
                }
            } else {
                val speed = when (e.kind) { 1 -> 112f; 2 -> 42f; else -> 66f } + wave * 1.1f
                if (dist > 30f) { e.x += dx / dist * speed * dt; e.y += dy / dist * speed * dt }
                if (dist < (if (e.kind == 2) 42f else 31f) && invulnerable <= 0f) {
                    damagePlayer((if (e.kind == 2) 23f else 15f) * dt)
                }
            }
            if (e.hp <= 0f) {
                iterator.remove()
                kills++; totalKills++
                val reward = if (e.boss) 130 else if (e.kind == 2) 16 else 9
                runGold += reward
                xp += if (e.boss) 110 else 15
                burst(e.x, e.y, if (e.boss) 28 else 9, if (e.boss) goldColor else red)
                if (showDamageNumbers) popups.add(Popup(e.x, e.y - 15f, "+$reward G", .9f, goldColor))
                if (xp >= level * 55) {
                    xp -= level * 55
                    level++
                    playTone(ToneGenerator.TONE_PROP_PROMPT)
                    maxHp += 8f
                    hp = min(maxHp, hp + 22f)
                    screen = Screen.LEVEL_UP
                }
                if (e.boss) {
                    runGold += 100
                    xp += 45
                    banner = "WARDEN DEFEATED"
                    waveBanner = 2.4f
                }
            }
        }
    }

    private fun updateShots(dt: Float) {
        val it = shots.iterator()
        while (it.hasNext()) {
            val s = it.next()
            s.x += s.vx * dt; s.y += s.vy * dt; s.life -= dt
            if (s.life <= 0f || s.x < -20f || s.x > sw + 20f || s.y < -20f || s.y > sh + 20f) {
                it.remove(); continue
            }
            if (hypot(s.x - playerX, s.y - playerY) < 21f && invulnerable <= 0f) {
                damagePlayer(s.damage)
                burst(s.x, s.y, 5, red)
                it.remove()
            }
        }
    }

    private fun damagePlayer(amount: Float) {
        hp -= amount
        if (amount > 1f) invulnerable = max(invulnerable, .12f)
    }

    private fun updateEffects(dt: Float) {
        val pi = particles.iterator()
        while (pi.hasNext()) {
            val p = pi.next()
            p.x += p.vx * dt; p.y += p.vy * dt
            p.vx *= .96f; p.vy *= .96f; p.life -= dt
            if (p.life <= 0f) pi.remove()
        }
        val fi = popups.iterator()
        while (fi.hasNext()) {
            val f = fi.next(); f.y -= 28f * dt; f.life -= dt
            if (f.life <= 0f) fi.remove()
        }
    }

    private fun burst(x: Float, y: Float, count: Int, color: Int) {
        repeat(count) {
            val a = rng.nextFloat() * PI.toFloat() * 2f
            val speed = rng.nextFloat() * 125f + 20f
            particles.add(Particle(x, y, cos(a) * speed, sin(a) * speed,
                rng.nextFloat() * .35f + .2f, .55f, color, rng.nextFloat() * 4f + 1.5f))
        }
    }

    private fun upgradeCards(): List<Upgrade> = listOf(
        Upgrade("HẮC ÁM", "Tăng 20% sát thương", { it.damage *= 1.2f }),
        Upgrade("SINH LỰC", "Tăng 25 máu tối đa và hồi 25 HP", { it.maxHp += 25f; it.hp = min(it.maxHp, it.hp + 25f) }),
        Upgrade("CUỒNG PHONG", "Tăng 15% tốc độ đánh", { it.attackPeriod = max(.18f, it.attackPeriod * .85f) })
    )

    private fun startRun() {
        screen = Screen.PLAYING
        runWon = false
        runReward = 0
        enemies.clear(); shots.clear(); particles.clear(); popups.clear()
        maxHp = 120f + permVitality * 15f
        hp = maxHp; xp = 0; level = 1; runGold = 0; wave = 1; kills = 0
        damage = 24f + permDamage * 5f
        attackPeriod = (.42f * (1f - permHaste * .04f)).coerceAtLeast(.22f)
        attackCooldown = 0f; skillCooldown = 0f; dashCooldown = 0f
        attackFxTimer = 0f; combo = 0; comboTimer = 0f
        skillPeriod = 8f; dashPeriod = 4.2f
        invulnerable = 0f; spawnTimer = 1.2f; spawnedThisWave = 0; waveQuota = 5
        playerX = sw * .5f; playerY = sh * .55f
        moveX = 0f; moveY = 0f; joyId = -1; attackHeld = false
        banner = when (selectedMode) { GameMode.STORY -> "CHƯƠNG 1 • KHỞI NGUYÊN"; GameMode.ENDLESS -> "CHẾ ĐỘ VÔ TẬN"; GameMode.DUNGEON -> "HẦM NGỤC • TẦNG 1"; GameMode.BOSS_RUSH -> "BOSS RUSH • TRẬN 1" }; waveBanner = 2.5f
    }

    private fun tierName(level: Int): String = when (level) {
        0 -> "COMMON"
        1 -> "RARE"
        2 -> "EPIC"
        3 -> "LEGENDARY"
        else -> "MYTHICAL"
    }

    private fun setSoundEnabled(enabled: Boolean) {
        soundEnabled = enabled
    }

    private fun playTone(toneType: Int) {
        if (!soundEnabled) return
        val id = when (toneType) {
            ToneGenerator.TONE_PROP_ACK -> sfxSlash
            ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD -> sfxHit
            ToneGenerator.TONE_PROP_BEEP2 -> sfxMagic
            else -> sfxReward
        }
        if (id != 0) soundPool?.play(id, .72f, .72f, 1, 0, 1f)
    }

    private fun buyUpgrade(index: Int) {
        val currentRank = when (index) { 0 -> permDamage; 1 -> permVitality; else -> permHaste }
        if (currentRank >= 4) return
        val cost = when (index) { 0 -> 100 * (permDamage + 1); 1 -> 120 * (permVitality + 1); else -> 150 * (permHaste + 1) }
        if (bankGold < cost) return
        bankGold -= cost
        when (index) { 0 -> permDamage++; 1 -> permVitality++; else -> permHaste++ }
        saveProgress()
    }

    private fun handleTap(x: Float, y: Float) {
        when (screen) {
            Screen.MENU -> {
                when {
                    y in (sh * .43f)..(sh * .57f) -> screen = Screen.MODES
                    y in (sh * .59f)..(sh * .71f) && x < sw * .5f -> screen = Screen.MODES
                    y in (sh * .59f)..(sh * .71f) -> screen = Screen.MAPS
                    y in (sh * .72f)..(sh * .85f) && x < sw * .5f -> screen = Screen.ARMORY
                    y in (sh * .72f)..(sh * .85f) -> screen = Screen.SETTINGS
                }
            }
            Screen.MODES -> {
                when {
                    y in (sh*.27f)..(sh*.47f) -> { selectedMode = if (x < sw*.5f) GameMode.STORY else GameMode.ENDLESS; startRun() }
                    y in (sh*.50f)..(sh*.70f) -> { selectedMode = if (x < sw*.5f) GameMode.DUNGEON else GameMode.BOSS_RUSH; startRun() }
                    y in (sh*.79f)..(sh*.92f) && x < sw*.5f -> screen = Screen.MAPS
                    y in (sh*.79f)..(sh*.92f) -> screen = Screen.MENU
                }
            }
            Screen.MAPS -> {
                if (y in (sh*.24f)..(sh*.76f)) {
                    val col = (x / (sw/3f)).toInt().coerceIn(0,2)
                    val row = if (y < sh*.52f) 0 else 1
                    mapIndex = (row*3+col).coerceIn(0,5)
                } else if (y > sh*.84f) screen = Screen.MENU
            }
            Screen.PAUSED -> {
                when {
                    y < sh * .53f -> screen = Screen.PLAYING
                    y < sh * .66f -> { showSettingsFromPause = true; screen = Screen.SETTINGS }
                    else -> { bankGold += runGold; runGold = 0; saveProgress(); screen = Screen.MENU }
                }
            }
            Screen.LEVEL_UP -> {
                val idx = ((x / sw * 3.6f).toInt()).coerceIn(0, 2)
                upgradeCards()[idx].apply(this)
                screen = Screen.PLAYING
                banner = "UPGRADE ACQUIRED"; waveBanner = 1.2f
            }
            Screen.GAME_OVER -> {
                if (y in (sh * .52f)..(sh * .66f)) startRun()
                else if (y in (sh * .66f)..(sh * .82f)) screen = Screen.MENU
            }
            Screen.ARMORY -> {
                when {
                    y in (sh * .17f)..(sh * .34f) -> buyUpgrade(0)
                    y in (sh * .36f)..(sh * .53f) -> buyUpgrade(1)
                    y in (sh * .55f)..(sh * .72f) -> buyUpgrade(2)
                    y > sh * .82f -> screen = Screen.MENU
                }
            }
            Screen.SETTINGS -> {
                when {
                    y in (sh * .36f)..(sh * .50f) -> setSoundEnabled(!soundEnabled)
                    y in (sh * .51f)..(sh * .65f) -> showDamageNumbers = !showDamageNumbers
                    y > sh * .67f -> screen = if (showSettingsFromPause) Screen.PAUSED else Screen.MENU
                }
                saveProgress()
            }
            else -> Unit
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val index = event.actionIndex
        val x = event.getX(index)
        val y = event.getY(index)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (screen != Screen.PLAYING) {
                    if (event.actionMasked == MotionEvent.ACTION_DOWN) handleTap(x, y)
                    return true
                }
                val id = event.getPointerId(index)
                if (x < sw * .30f && y > sh * .52f && joyId == -1) {
                    joyId = id; joyTouchX = x; joyTouchY = y; updateJoystick(x, y)
                } else if (x > sw - 125f && y > sh - 145f && attackId == -1) {
                    attackId = id; attackHeld = true
                } else if (x > sw - 220f && x <= sw - 120f && y > sh - 130f && skillId == -1) {
                    skillId = id; skillQueued = true
                } else if (x > sw - 295f && x <= sw - 210f && y > sh - 120f && dashId == -1) {
                    dashId = id; dashQueued = true
                } else if (x > sw - 58f && y < 100f) {
                    clearTouchState()
                    screen = Screen.PAUSED
                    saveProgress()
                }
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val id = event.getPointerId(i)
                    if (id == joyId) {
                        joyTouchX = event.getX(i); joyTouchY = event.getY(i)
                        updateJoystick(joyTouchX, joyTouchY)
                    }
                }
                return true
            }
            MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val id = event.getPointerId(index)
                if (id == joyId) { joyId = -1; moveX = 0f; moveY = 0f }
                if (id == attackId) { attackId = -1; attackHeld = false }
                if (id == skillId) skillId = -1
                if (id == dashId) dashId = -1
                if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) {
                    joyId = -1; attackId = -1; skillId = -1; dashId = -1
                    attackHeld = false; moveX = 0f; moveY = 0f
                }
                return true
            }
        }
        return true
    }

    private fun updateJoystick(x: Float, y: Float) {
        val cx = 88f; val cy = sh - 88f
        val dx = x - cx; val dy = y - cy
        val d = hypot(dx, dy).coerceAtLeast(1f)
        val scale = min(1f, d / 55f)
        moveX = dx / d * scale
        moveY = dy / d * scale
    }
}
