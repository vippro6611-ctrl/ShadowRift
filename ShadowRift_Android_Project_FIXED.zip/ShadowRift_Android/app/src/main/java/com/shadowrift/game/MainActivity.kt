package com.shadowrift.game

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.*
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
             View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        setContentView(GameView(this))
    }
}

private data class Mob(var x: Float, var y: Float, var hp: Float, var maxHp: Float,
                       var boss: Boolean = false, var hitFlash: Float = 0f)

private class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var w = 0f; private var h = 0f
    private var last = System.nanoTime()
    private var playerX = 0f; private var playerY = 0f
    private var hp = 100f; private var maxHp = 100f
    private var xp = 0; private var level = 1; private var gold = 0
    private var wave = 1; private var kills = 0
    private var attackCd = 0f; private var skillCd = 0f
    private var invuln = 0f; private var spawnTimer = 1f
    private var gameOver = false
    private val mobs = mutableListOf<Mob>()
    private var joyPointer = -1
    private var joyX = 0f; private var joyY = 0f
    private var moveX = 0f; private var moveY = 0f
    private var attackHeld = false
    private var skillHeld = false
    private var showUpgrade = false
    private var upgradeChoice = 0
    private var message = "SỐNG SÓT QUA CÁC ĐỢT QUÁI!"
    private var messageTime = 3f
    private val rnd = Random(System.currentTimeMillis())

    init { isFocusable = true }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        w = width.toFloat(); h = height.toFloat()
        if (playerX == 0f) { playerX = w * .5f; playerY = h * .55f }
        val now = System.nanoTime()
        val dt = min(.04f, (now-last)/1_000_000_000f).coerceAtLeast(0f)
        last = now
        if (!gameOver && !showUpgrade) update(dt)
        drawWorld(c)
        if (gameOver) drawGameOver(c)
        if (showUpgrade) drawUpgrade(c)
        postInvalidateOnAnimation()
    }

    private fun update(dt: Float) {
        attackCd = (attackCd-dt).coerceAtLeast(0f)
        skillCd = (skillCd-dt).coerceAtLeast(0f)
        invuln = (invuln-dt).coerceAtLeast(0f)
        messageTime = (messageTime-dt).coerceAtLeast(0f)
        playerX = (playerX + moveX * 260f * dt).coerceIn(35f, w-35f)
        playerY = (playerY + moveY * 260f * dt).coerceIn(65f, h-35f)
        spawnTimer -= dt
        if (spawnTimer <= 0f) {
            val boss = wave % 5 == 0 && mobs.none { it.boss }
            val edge = rnd.nextInt(4)
            val x = when(edge) { 0 -> 25f; 1 -> w-25f; else -> rnd.nextFloat()*w }
            val y = when(edge) { 2 -> 55f; 3 -> h-25f; else -> 70f+rnd.nextFloat()*(h-100f) }
            val mh = if (boss) 260f + wave*18f else 35f + wave*5f
            mobs.add(Mob(x,y,mh,mh,boss))
            spawnTimer = if (boss) 99f else (1.15f-wave*.025f).coerceAtLeast(.42f)
            if (boss) announce("BOSS XUẤT HIỆN!")
        }
        if (attackHeld && attackCd <= 0f) {
            attackCd = .32f
            val target = mobs.minByOrNull { hypot(it.x-playerX,it.y-playerY) }
            if (target != null && hypot(target.x-playerX,target.y-playerY) < 145f) {
                target.hp -= 24f + level*3f
                target.hitFlash = .12f
            }
        }
        if (skillHeld && skillCd <= 0f) {
            skillCd = 8f
            mobs.forEach {
                if (hypot(it.x-playerX,it.y-playerY) < 205f) {
                    it.hp -= if (it.boss) 95f else 115f
                    it.hitFlash = .2f
                }
            }
            announce("SHADOW BURST!")
        }
        val iter = mobs.iterator()
        while (iter.hasNext()) {
            val m = iter.next()
            m.hitFlash = (m.hitFlash-dt).coerceAtLeast(0f)
            val dx = playerX-m.x; val dy = playerY-m.y
            val d = hypot(dx,dy).coerceAtLeast(1f)
            val speed = if (m.boss) 48f else 72f + wave*1.4f
            if (d > 34f) { m.x += dx/d*speed*dt; m.y += dy/d*speed*dt }
            else if (invuln <= 0f) {
                hp -= if (m.boss) 18f*dt else 12f*dt
                if (hp <= 0f) { hp = 0f; gameOver = true }
            }
            if (m.hp <= 0f) {
                iter.remove(); kills++; gold += if (m.boss) 100 else 8
                xp += if (m.boss) 80 else 12
                if (xp >= level*50) {
                    xp -= level*50; level++; maxHp += 12f; hp = min(maxHp,hp+30f)
                    showUpgrade = true; announce("LÊN CẤP $level!")
                }
                if (m.boss) { wave++; spawnTimer = 2f; announce("ĐÃ HẠ BOSS! ĐỢT $wave") }
            }
        }
    }

    private fun announce(s: String) { message=s; messageTime=2.5f }

    private fun drawWorld(c: Canvas) {
        c.drawColor(Color.rgb(10,8,22))
        // Subtle arena grid
        p.color = Color.rgb(25,20,43); p.strokeWidth=1f
        var gx=0f
        while(gx<w){ c.drawLine(gx,45f,gx,h,p); gx+=48f }
        var gy=48f
        while(gy<h){ c.drawLine(0f,gy,w,gy,p); gy+=48f }
        // Rift glow
        p.shader = android.graphics.RadialGradient(w*.5f,h*.52f,w*.42f,
            intArrayOf(0x332D1455,0x00100820),null,android.graphics.Shader.TileMode.CLAMP)
        c.drawRect(0f,0f,w,h,p); p.shader=null
        // Enemies
        mobs.forEach { m ->
            p.color = if(m.boss) Color.rgb(210,45,80) else Color.rgb(220,75,95)
            c.drawCircle(m.x,m.y,if(m.boss) 25f else 13f,p)
            p.color = Color.rgb(35,12,25)
            c.drawCircle(m.x-4,m.y-3,3f,p); c.drawCircle(m.x+4,m.y-3,3f,p)
            val bw=if(m.boss) 62f else 30f
            p.color=Color.DKGRAY; c.drawRoundRect(m.x-bw/2,m.y-(if(m.boss)39f else 24f),m.x+bw/2,m.y-(if(m.boss)34f else 20f),3f,3f,p)
            p.color=Color.rgb(255,65,90)
            c.drawRoundRect(m.x-bw/2,m.y-(if(m.boss)39f else 24f),m.x-bw/2+bw*(m.hp/m.maxHp).coerceIn(0f,1f),m.y-(if(m.boss)34f else 20f),3f,3f,p)
        }
        // Player
        p.color=if(invuln>0f) Color.WHITE else Color.rgb(125,90,235)
        c.drawCircle(playerX,playerY,16f,p)
        p.color=Color.rgb(225,215,255); c.drawCircle(playerX,playerY-5f,7f,p)
        p.color=Color.rgb(40,25,75); c.drawRoundRect(playerX-9,playerY+5,playerX+9,playerY+16,5f,5f,p)
        drawHud(c); drawControls(c)
        if(messageTime>0f) {
            p.color=Color.WHITE; p.textSize=19f; p.typeface=Typeface.DEFAULT_BOLD; p.textAlign=Paint.Align.CENTER
            c.drawText(message,w/2, h*.19f,p)
        }
    }

    private fun text(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,align:Paint.Align=Paint.Align.LEFT) {
        p.color=color; p.textSize=size; p.typeface=Typeface.DEFAULT_BOLD; p.textAlign=align
        c.drawText(s,x,y,p)
    }
    private fun bar(c:Canvas,x:Float,y:Float,bw:Float,bh:Float,v:Float,max:Float,col:Int) {
        p.color=0xff30283f.toInt(); c.drawRoundRect(x,y,x+bw,y+bh,8f,8f,p)
        p.color=col; c.drawRoundRect(x,y,x+bw*(v/max).coerceIn(0f,1f),y+bh,8f,8f,p)
    }
    private fun drawHud(c:Canvas) {
        text(c,"SHADOW RIFT",20f,29f,20f,0xffd9c8ff.toInt())
        text(c,"ĐỢT $wave   •   CẤP $level   •   VÀNG $gold",20f,53f,13f,Color.WHITE)
        bar(c,20f,64f,180f,9f,hp,maxHp,0xffe94b69.toInt())
        text(c,"HP ${hp.toInt()}/${maxHp.toInt()}",210f,73f,11f,Color.WHITE)
        bar(c,20f,81f,180f,6f,xp.toFloat(),(level*50).toFloat(),0xff9c68ff.toInt())
        val boss=mobs.firstOrNull{it.boss}
        if(boss!=null) {
            val bw=min(300f,w*.42f)
            bar(c,(w-bw)/2,20f,bw,10f,boss.hp,boss.maxHp,0xffe52d55.toInt())
            text(c,"RIFT BOSS",w/2,15f,11f,Color.WHITE,Paint.Align.CENTER)
        }
        text(c,"HẠ GỤC: $kills",w-20f,28f,13f,Color.WHITE,Paint.Align.RIGHT)
    }
    private fun button(c:Canvas,x:Float,y:Float,r:Float,label:String,col:Int) {
        p.color=0xaa171126.toInt(); c.drawCircle(x,y,r+5,p)
        p.color=col; c.drawCircle(x,y,r,p)
        p.color=Color.WHITE; p.style=Paint.Style.STROKE; p.strokeWidth=2f
        c.drawCircle(x,y,r,p); p.style=Paint.Style.FILL
        text(c,label,x,y+5f,if(label.length>4) 11f else 15f,Color.WHITE,Paint.Align.CENTER)
    }
    private fun drawControls(c:Canvas) {
        val cx=92f; val cy=h-92f
        p.color=0x553f365e; c.drawCircle(cx,cy,58f,p)
        p.color=0x997f70a8.toInt(); c.drawCircle(if(joyPointer>=0) joyX else cx,if(joyPointer>=0) joyY else cy,24f,p)
        button(c,w-88f,h-90f,43f,"ĐÁNH",0xff9b4bd4.toInt())
        button(c,w-185f,h-65f,34f,"SKILL",0xff5140b8.toInt())
        text(c,"CD ${skillCd.toInt()}s",w-185f,h-20f,10f,Color.WHITE,Paint.Align.CENTER)
    }
    private fun drawGameOver(c:Canvas) {
        p.color=0xdd080611.toInt(); c.drawRect(0f,0f,w,h,p)
        text(c,"BẠN ĐÃ GỤC NGÃ",w/2,h*.38f,32f,0xffff647d.toInt(),Paint.Align.CENTER)
        text(c,"Đã sống đến đợt $wave  •  Hạ $kills quái  •  $gold vàng",w/2,h*.49f,17f,Color.WHITE,Paint.Align.CENTER)
        button(c,w/2,h*.66f,55f,"CHƠI LẠI",0xff7546c8.toInt())
    }
    private fun drawUpgrade(c:Canvas) {
        p.color=0xee090617.toInt(); c.drawRect(0f,0f,w,h,p)
        text(c,"CHỌN NÂNG CẤP",w/2,h*.27f,27f,0xffdfcaff.toInt(),Paint.Align.CENTER)
        val labels=listOf("HỒI 40 HP","TĂNG 25% SÁT THƯƠNG","TĂNG TỐC ĐÁNH")
        for(i in 0..2) {
            val x=w*(.25f+i*.25f)
            p.color=if(upgradeChoice==i) 0xff8954d8.toInt() else 0xff302342.toInt()
            c.drawRoundRect(x-82,h*.42f,x+82,h*.68f,16f,16f,p)
            text(c,labels[i],x,h*.56f,13f,Color.WHITE,Paint.Align.CENTER)
        }
        text(c,"CHẠM ĐỂ CHỌN",w/2,h*.79f,14f,Color.LTGRAY,Paint.Align.CENTER)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x=e.x; val y=e.y
        when(e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if(gameOver) { reset(); return true }
                if(showUpgrade) {
                    val idx=((x/w*4f)-.5f).toInt().coerceIn(0,2)
                    when(idx) { 0 -> hp=min(maxHp,hp+40f); 1 -> maxHp+=0f; 2 -> attackCd=0f }
                    if(idx==1) mobs.forEach { it.hp-=25f }
                    showUpgrade=false; return true
                }
                if(x< w*.34f && y>h*.55f) {
                    joyPointer=e.getPointerId(e.actionIndex); joyX=x; joyY=y; updateJoy(x,y)
                } else if(x>w*.78f && y>h*.55f) attackHeld=true
                else if(x>w*.62f && y>h*.65f) skillHeld=true
            }
            MotionEvent.ACTION_MOVE -> {
                if(joyPointer>=0) {
                    val i=(0 until e.pointerCount).firstOrNull{e.getPointerId(it)==joyPointer}
                    if(i!=null) { joyX=e.getX(i); joyY=e.getY(i); updateJoy(joyX,joyY) }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val id=e.getPointerId(e.actionIndex)
                if(id==joyPointer) { joyPointer=-1; moveX=0f; moveY=0f }
                if(x>w*.78f && y>h*.55f) attackHeld=false
                if(x>w*.62f && x<=w*.78f && y>h*.65f) skillHeld=false
                if(e.actionMasked==MotionEvent.ACTION_UP) { attackHeld=false; skillHeld=false }
            }
        }
        return true
    }
    private fun updateJoy(x:Float,y:Float) {
        val dx=x-92f; val dy=y-(h-92f); val d=hypot(dx,dy).coerceAtLeast(1f)
        moveX=(dx/d).coerceIn(-1f,1f); moveY=(dy/d).coerceIn(-1f,1f)
    }
    private fun reset() {
        hp=100f; maxHp=100f; xp=0; level=1; gold=0; wave=1; kills=0
        mobs.clear(); gameOver=false; showUpgrade=false; spawnTimer=1f
        playerX=w*.5f; playerY=h*.55f; announce("BẮT ĐẦU CUỘC SĂN!")
    }
}
