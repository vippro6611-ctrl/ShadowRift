# Shadow Rift — Android project

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload all files and folders in this ZIP to the repository (keep `.github/workflows/build-apk.yml`).
3. Open the repository's **Actions** tab.
4. Select **Build Shadow Rift APK** → **Run workflow**.
5. Wait for the green check mark, open the completed run, and download artifact **ShadowRift-APK**.
6. Extract the downloaded artifact and install `app-debug.apk` on Android. If Android asks, allow installation from that source.

## Build locally
Requires JDK 17, Android SDK platform 35, and Gradle 8.9:
`gradle assembleDebug`

This is an early playable prototype. It includes touch movement, attack, area skill, enemy waves, a boss every five waves, XP/level-up choices, gold and a game-over/restart loop.
