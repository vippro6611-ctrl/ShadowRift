extends Node2D

const W := 960.0
const H := 540.0
const TILE_W := 72.0
const TILE_H := 36.0
const SAVE_PATH := "user://shadow_rift_save.cfg"

enum Screen { MENU, MODES, PLAY, INVENTORY, PAUSE, GAME_OVER }
enum Mode { STORY, DUNGEON, ENDLESS, BOSS_RUSH }

var screen: Screen = Screen.MENU
var mode: Mode = Mode.DUNGEON
var mode_names := ["STORY", "DUNGEON", "ENDLESS", "BOSS RUSH"]
var mode_desc := [
    "Follow the Riftborn story across six regions.",
    "Explore rooms, find treasure and defeat the floor boss.",
    "Survive endless waves and beat your best record.",
    "Face a chain of powerful bosses."
]
var map_names := ["Ruined Kingdom", "Cursed Forest", "Infernal Depths", "Frozen Abyss", "Ancient Temple", "Shadow Realm"]
var map_index := 0
var chapter := 1
var floor_no := 1
var wave_no := 1
var boss_index := 0

var player := Vector2(0, 0)
var player_hp := 100.0
var player_max_hp := 100.0
var player_speed := 220.0
var player_gold := 0
var player_level := 1
var player_xp := 0
var weapon_power := 16.0
var armor := 0.0
var facing := Vector2(1, 0)
var attack_cd := 0.0
var skill_cd := 0.0
var dash_cd := 0.0
var hurt_flash := 0.0
var attack_anim := 0.0
var dash_timer := 0.0
var skill_anim := 0.0
var combo := 0
var combo_timer := 0.0
var elapsed := 0.0

var enemies: Array[Dictionary] = []
var drops: Array[Dictionary] = []
var particles: Array[Dictionary] = []
var obstacles: Array[Vector2] = []
var joystick_id := -1
var joystick_origin := Vector2(120, 420)
var joystick_vec := Vector2.ZERO
var touch_controls := true
var toast := ""
var toast_timer := 0.0
var best_endless := 0
var kills := 0
var room_seed := 1
var audio_players: Dictionary = {}
var sound_enabled := true
var music_enabled := true
var music_volume := 0.65
var sfx_volume := 0.8
var settings_page := 0
var rng := RandomNumberGenerator.new()

func _ready() -> void:
    rng.randomize()
    _load_save()
    _setup_audio()
    set_process(true)
    _show_toast("THE RIFT IS CALLING")

func _setup_audio() -> void:
    for key in ["slash", "hit", "magic", "loot", "level"]:
        var p := AudioStreamPlayer.new()
        p.name = "SFX_" + key
        p.volume_db = linear_to_db(sfx_volume)
        add_child(p)
        var path := "res://assets/audio/" + key + ".wav"
        if ResourceLoader.exists(path):
            p.stream = load(path)
        audio_players[key] = p

func _play_sfx(key: String) -> void:
    if not sound_enabled or not audio_players.has(key):
        return
    var p: AudioStreamPlayer = audio_players[key]
    if p.stream:
        p.stop()
        p.volume_db = linear_to_db(max(0.01, sfx_volume))
        p.play()

func _process(delta: float) -> void:
    elapsed += delta
    toast_timer = maxf(0.0, toast_timer - delta)
    attack_cd = maxf(0.0, attack_cd - delta)
    skill_cd = maxf(0.0, skill_cd - delta)
    dash_cd = maxf(0.0, dash_cd - delta)
    hurt_flash = maxf(0.0, hurt_flash - delta)
    attack_anim = maxf(0.0, attack_anim - delta)
    skill_anim = maxf(0.0, skill_anim - delta)
    dash_timer = maxf(0.0, dash_timer - delta)
    combo_timer = maxf(0.0, combo_timer - delta)
    if combo_timer <= 0.0:
        combo = 0
    for p in particles:
        p.life -= delta
        p.pos += p.vel * delta
        p.vel *= 0.94
    particles = particles.filter(func(p): return p.life > 0.0)

    if screen == Screen.PLAY:
        _update_game(delta)
    queue_redraw()

func _update_game(delta: float) -> void:
    var move := _get_move_input()
    if move.length() > 0.08:
        facing = move.normalized()
        var speed := player_speed * (1.7 if dash_timer > 0.0 else 1.0)
        var candidate := player + move.normalized() * speed * delta
        if not _blocked(candidate):
            player = candidate
    for e in enemies:
        e.attack_cd = maxf(0.0, e.attack_cd - delta)
        e.flash = maxf(0.0, e.flash - delta)
        e.anim += delta
        var to_player: Vector2 = player - e.pos
        var dist := to_player.length()
        if dist > e.range:
            var dir := to_player.normalized()
            var next_pos: Vector2 = e.pos + dir * e.speed * delta
            if not _blocked(next_pos):
                e.pos = next_pos
        elif e.attack_cd <= 0.0:
            e.attack_cd = 1.25 if not e.boss else 0.85
            _damage_player(8.0 if not e.boss else 15.0)
    for d in drops:
        if player.distance_to(d.pos) < 30.0:
            if d.kind == "gold":
                player_gold += d.value
                _play_sfx("loot")
                _show_toast("+%d GOLD" % d.value)
            else:
                weapon_power += 2.0
                _show_toast("SHADOW SHARD  +2 POWER")
            _burst(d.pos, Color(1.0, 0.78, 0.25), 8)
            drops.erase(d)
            break
    if enemies.is_empty():
        _on_room_cleared()
    if player_hp <= 0.0:
        screen = Screen.GAME_OVER
        _save()

func _get_move_input() -> Vector2:
    var v := Vector2.ZERO
    if Input.is_action_pressed("move_up"): v.y -= 1
    if Input.is_action_pressed("move_down"): v.y += 1
    if Input.is_action_pressed("move_left"): v.x -= 1
    if Input.is_action_pressed("move_right"): v.x += 1
    if joystick_vec.length() > 0.08:
        v = joystick_vec
    return v.normalized() if v.length() > 1.0 else v

func _blocked(pos: Vector2) -> bool:
    for o in obstacles:
        if pos.distance_to(o) < 42.0:
            return true
    return false

func _start_run(selected_mode: int) -> void:
    mode = selected_mode
    screen = Screen.PLAY
    player = Vector2.ZERO
    player_hp = player_max_hp
    attack_cd = 0
    skill_cd = 0
    dash_cd = 0
    combo = 0
    kills = 0
    floor_no = 1
    wave_no = 1
    chapter = 1
    boss_index = 0
    map_index = 0 if mode == Mode.STORY else rng.randi_range(0, map_names.size() - 1)
    _generate_room()
    _show_toast(mode_names[mode] + "  /  " + map_names[map_index].to_upper())

func _generate_room() -> void:
    room_seed += 1
    rng.seed = room_seed * 9137 + floor_no * 91 + wave_no * 17
    enemies.clear()
    drops.clear()
    obstacles.clear()
    for i in range(7):
        var ox := rng.randf_range(-470, 470)
        var oy := rng.randf_range(-300, 300)
        if Vector2(ox, oy).length() > 115:
            obstacles.append(Vector2(ox, oy))
    var count := 4 + mini(floor_no, 5) + mini(wave_no, 5)
    if mode == Mode.BOSS_RUSH:
        count = 1
    if mode == Mode.STORY:
        count = 4 + chapter
    for i in range(count):
        var p := Vector2(rng.randf_range(-380, 380), rng.randf_range(-240, 240))
        if p.length() < 150:
            p += Vector2(230, 170)
        _spawn_enemy(p, false)
    if mode == Mode.BOSS_RUSH or floor_no % 3 == 0 or (mode == Mode.STORY and chapter % 2 == 0):
        _spawn_enemy(Vector2(0, -245), true)
    _show_toast("FLOOR %d  •  WAVE %d" % [floor_no, wave_no])

func _spawn_enemy(pos: Vector2, is_boss: bool) -> void:
    var types := ["Wraith", "Rift Hound", "Cultist", "Stoneguard"]
    var idx := rng.randi_range(0, types.size() - 1)
    var hp := (42.0 + floor_no * 7.0) * (3.8 if is_boss else 1.0)
    enemies.append({
        "pos": pos, "hp": hp, "max_hp": hp,
        "speed": (72.0 + rng.randf_range(0, 25)) * (0.72 if is_boss else 1.0),
        "range": 52.0 if not is_boss else 82.0,
        "attack_cd": 0.6, "flash": 0.0, "anim": 0.0,
        "boss": is_boss, "type": "Rift Sovereign" if is_boss else types[idx],
        "damage": 15.0 if is_boss else 8.0
    })

func _on_room_cleared() -> void:
    if drops.size() > 0:
        return
    if mode == Mode.STORY:
        chapter += 1
        if chapter > 8:
            screen = Screen.GAME_OVER
            _show_toast("STORY CHAPTER COMPLETE")
            _save()
            return
        map_index = mini(5, int((chapter - 1) / 2))
    elif mode == Mode.DUNGEON:
        floor_no += 1
    elif mode == Mode.ENDLESS:
        wave_no += 1
        if wave_no > best_endless:
            best_endless = wave_no - 1
    elif mode == Mode.BOSS_RUSH:
        boss_index += 1
        floor_no += 1
        if boss_index >= 6:
            screen = Screen.GAME_OVER
            _show_toast("BOSS RUSH CLEARED")
            _save()
            return
    player_gold += 12 + floor_no * 3
    player_xp += 25 + floor_no * 3
    if player_xp >= player_level * 100:
        player_xp -= player_level * 100
        player_level += 1
        player_max_hp += 8
        player_hp = player_max_hp
        weapon_power += 3
        _play_sfx("level")
        _show_toast("LEVEL UP  •  LEVEL %d" % player_level)
    if rng.randf() < 0.55:
        drops.append({"pos": Vector2(rng.randf_range(-120, 120), rng.randf_range(-80, 80)), "kind": "shard", "value": 1})
    _save()
    _generate_room()

func _damage_player(amount: float) -> void:
    player_hp = maxf(0.0, player_hp - maxf(1.0, amount - armor))
    hurt_flash = 0.22
    _play_sfx("hit")
    _burst(player, Color(0.95, 0.16, 0.24), 5)

func _attack() -> void:
    if attack_cd > 0.0 or screen != Screen.PLAY:
        return
    attack_cd = 0.38
    attack_anim = 0.28
    combo = (combo % 3) + 1
    combo_timer = 1.0
    _play_sfx("slash")
    var target_index := -1
    var nearest := 105.0
    for i in range(enemies.size()):
        var e: Dictionary = enemies[i]
        var dist: float = player.distance_to(e.pos)
        if dist < nearest:
            nearest = dist
            target_index = i
    if target_index >= 0:
        var e: Dictionary = enemies[target_index]
        e.hp -= weapon_power * (1.0 + combo * 0.12)
        e.flash = 0.16
        _burst(e.pos, Color(0.85, 0.8, 1.0), 7)
        if e.hp <= 0.0:
            _kill_enemy(target_index)

func _skill() -> void:
    if skill_cd > 0.0 or screen != Screen.PLAY:
        return
    skill_cd = 5.0
    skill_anim = 0.5
    _play_sfx("magic")
    _burst(player, Color(0.58, 0.25, 1.0), 34)
    for i in range(enemies.size() - 1, -1, -1):
        var e: Dictionary = enemies[i]
        if player.distance_to(e.pos) < 185.0:
            e.hp -= weapon_power * 2.8
            e.flash = 0.25
            if e.hp <= 0.0:
                _kill_enemy(i)

func _dash() -> void:
    if dash_cd > 0.0 or screen != Screen.PLAY:
        return
    dash_cd = 2.0
    dash_timer = 0.18
    player += (facing if facing.length() > 0.1 else Vector2.RIGHT) * 92.0
    _burst(player, Color(0.55, 0.3, 1.0), 12)

func _kill_enemy(index: int) -> void:
    var e: Dictionary = enemies[index]
    var pos: Vector2 = e.pos
    var boss: bool = e.boss
    _burst(pos, Color(0.62, 0.28, 1.0), 18 if boss else 9)
    drops.append({"pos": pos, "kind": "gold", "value": 35 if boss else 8})
    if rng.randf() < 0.16 or boss:
        drops.append({"pos": pos + Vector2(20, 12), "kind": "shard", "value": 1})
    enemies.remove_at(index)
    kills += 1
    _play_sfx("hit")

func _burst(pos: Vector2, color: Color, count: int) -> void:
    for i in range(count):
        var a := rng.randf() * TAU
        var sp := rng.randf_range(35, 180)
        particles.append({"pos": pos, "vel": Vector2(cos(a), sin(a)) * sp, "life": rng.randf_range(0.18, 0.55), "max": 0.55, "color": color})

func _show_toast(msg: String) -> void:
    toast = msg
    toast_timer = 2.0

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ESCAPE:
            if screen == Screen.PLAY: screen = Screen.PAUSE
            elif screen == Screen.PAUSE: screen = Screen.PLAY
        if event.is_action_pressed("attack"): _attack()
        if event.is_action_pressed("skill"): _skill()
        if event.is_action_pressed("dash"): _dash()
    if event is InputEventScreenTouch:
        if event.pressed:
            _touch_down(event.index, event.position)
        else:
            _touch_up(event.index)
    if event is InputEventScreenDrag:
        if event.index == joystick_id:
            joystick_vec = ((event.position - joystick_origin) / 58.0).limit_length(1.0)
    if event is InputEventMouseButton and event.pressed:
        _handle_ui_click(event.position)

func _touch_down(id: int, pos: Vector2) -> void:
    if screen == Screen.PLAY and pos.x < 250 and pos.y > 300:
        joystick_id = id
        joystick_origin = pos
        joystick_vec = Vector2.ZERO
        return
    _handle_ui_click(pos)

func _touch_up(id: int) -> void:
    if id == joystick_id:
        joystick_id = -1
        joystick_vec = Vector2.ZERO

func _handle_ui_click(pos: Vector2) -> void:
    if screen == Screen.MENU:
        if Rect2(330, 270, 300, 62).has_point(pos): screen = Screen.MODES
        elif Rect2(330, 345, 300, 52).has_point(pos): screen = Screen.INVENTORY
        elif Rect2(330, 410, 300, 52).has_point(pos): _show_toast("SETTINGS  •  MUSIC / SFX")
    elif screen == Screen.MODES:
        if Rect2(90, 175, 370, 100).has_point(pos): _start_run(Mode.STORY)
        elif Rect2(500, 175, 370, 100).has_point(pos): _start_run(Mode.DUNGEON)
        elif Rect2(90, 300, 370, 100).has_point(pos): _start_run(Mode.ENDLESS)
        elif Rect2(500, 300, 370, 100).has_point(pos): _start_run(Mode.BOSS_RUSH)
        elif pos.y < 80: screen = Screen.MENU
    elif screen == Screen.PLAY:
        if Rect2(780, 395, 150, 130).has_point(pos): _attack()
        elif Rect2(650, 410, 105, 105).has_point(pos): _skill()
        elif Rect2(550, 430, 85, 85).has_point(pos): _dash()
        elif Rect2(895, 12, 52, 45).has_point(pos): screen = Screen.PAUSE
    elif screen == Screen.PAUSE:
        if Rect2(330, 240, 300, 58).has_point(pos): screen = Screen.PLAY
        elif Rect2(330, 310, 300, 58).has_point(pos): screen = Screen.MODES
        elif Rect2(330, 380, 300, 58).has_point(pos): screen = Screen.MENU
    elif screen == Screen.INVENTORY:
        if pos.y < 90: screen = Screen.MENU
        elif Rect2(330, 350, 300, 55).has_point(pos) and player_gold >= 50:
            player_gold -= 50
            weapon_power += 4
            _show_toast("WEAPON UPGRADED")
            _save()
    elif screen == Screen.GAME_OVER:
        if Rect2(330, 320, 300, 60).has_point(pos): screen = Screen.MODES
        elif Rect2(330, 390, 300, 60).has_point(pos): screen = Screen.MENU

func _iso(p: Vector2) -> Vector2:
    return Vector2((p.x - p.y) * 0.7071, (p.x + p.y) * 0.35355)

func _draw() -> void:
    draw_rect(Rect2(0, 0, W, H), Color("#100d18"))
    if screen == Screen.MENU:
        _draw_menu()
    elif screen == Screen.MODES:
        _draw_modes()
    elif screen == Screen.INVENTORY:
        _draw_inventory()
    elif screen == Screen.PLAY or screen == Screen.PAUSE:
        _draw_world()
        _draw_hud()
        if screen == Screen.PAUSE: _draw_pause()
    elif screen == Screen.GAME_OVER:
        _draw_game_over()
    if toast_timer > 0.0:
        _panel(Rect2(285, 24, 390, 42), Color(0.08, 0.05, 0.12, 0.92))
        _center_text(toast, Vector2(480, 51), 15, Color("#d9c8ff"))

func _draw_menu() -> void:
    _draw_backdrop()
    _center_text("SHADOW RIFT", Vector2(480, 130), 54, Color("#e9ddff"))
    _center_text("DESCEND INTO THE UNKNOWN", Vector2(480, 172), 16, Color("#9f83c7"))
    _draw_button(Rect2(330, 270, 300, 62), "ENTER THE RIFT", true)
    _draw_button(Rect2(330, 345, 300, 52), "CHARACTER  /  INVENTORY", false)
    _draw_button(Rect2(330, 410, 300, 52), "SETTINGS", false)
    _center_text("2.5D ACTION DUNGEON CRAWLER  •  OFFLINE", Vector2(480, 510), 12, Color("#746783"))

func _draw_modes() -> void:
    _draw_backdrop()
    _center_text("CHOOSE YOUR PATH", Vector2(480, 88), 34, Color("#e9ddff"))
    _center_text("Every descent tells a different story.", Vector2(480, 120), 14, Color("#9f83c7"))
    var rects := [Rect2(90,175,370,100), Rect2(500,175,370,100), Rect2(90,300,370,100), Rect2(500,300,370,100)]
    var colors := [Color("#352448"), Color("#263c39"), Color("#43263e"), Color("#473323")]
    for i in range(4):
        _panel(rects[i], colors[i])
        draw_rect(rects[i], Color("#a989d8"), false, 2)
        draw_string(ThemeDB.fallback_font, Vector2(rects[i].position.x + 22, rects[i].position.y + 35), mode_names[i], HORIZONTAL_ALIGNMENT_LEFT, -1, 22, Color("#f0e8ff"))
        draw_string(ThemeDB.fallback_font, Vector2(rects[i].position.x + 22, rects[i].position.y + 66), mode_desc[i], HORIZONTAL_ALIGNMENT_LEFT, rects[i].size.x - 40, 13, Color("#c1b1d4"))
    _center_text("TAP A MODE TO BEGIN     •     BACK", Vector2(480, 465), 14, Color("#a78acb"))

func _draw_inventory() -> void:
    _draw_backdrop()
    _center_text("CHARACTER & ARMORY", Vector2(480, 90), 34, Color("#e9ddff"))
    _panel(Rect2(220, 140, 520, 275), Color("#21192e"))
    _center_text("RIFTWALKER  •  LEVEL %d" % player_level, Vector2(480, 190), 21, Color("#dbc7ff"))
    _center_text("Weapon Power: %.0f" % weapon_power, Vector2(480, 240), 17, Color("#e7e0f0"))
    _center_text("Armor: %.0f" % armor, Vector2(480, 270), 17, Color("#e7e0f0"))
    _center_text("Gold: %d" % player_gold, Vector2(480, 300), 17, Color("#f6cf71"))
    _draw_button(Rect2(330, 350, 300, 55), "UPGRADE WEAPON  •  50 GOLD", true)
    _center_text("TAP TOP AREA TO RETURN", Vector2(480, 475), 13, Color("#9f83c7"))

func _draw_world() -> void:
    var bg := [Color("#181525"), Color("#17221e"), Color("#25151d"), Color("#17212a"), Color("#201c2d"), Color("#171326")][map_index]
    draw_rect(Rect2(0, 0, W, H), bg)
    var center := Vector2(480, 270)
    # atmospheric glows
    for i in range(7):
        draw_circle(center + Vector2(sin(elapsed * 0.15 + i) * 280, cos(elapsed * 0.12 + i * 2) * 160), 90 + i * 13, Color(0.34, 0.18, 0.52, 0.025))
    var cam := center - _iso(player)
    for y in range(-11, 12):
        for x in range(-13, 14):
            var worldp := Vector2(x * 64, y * 64)
            var sp := _iso(worldp) + cam
            if sp.x < -100 or sp.x > 1060 or sp.y < -100 or sp.y > 650: continue
            var tint := 0.025 + float((x * 17 + y * 13) % 5) * 0.006
            var c := Color(0.22 + tint, 0.18 + tint, 0.27 + tint, 1)
            draw_colored_polygon(PackedVector2Array([sp + Vector2(0,-TILE_H/2), sp + Vector2(TILE_W/2,0), sp + Vector2(0,TILE_H/2), sp + Vector2(-TILE_W/2,0)]), c)
            draw_polyline(PackedVector2Array([sp + Vector2(0,-TILE_H/2), sp + Vector2(TILE_W/2,0), sp + Vector2(0,TILE_H/2), sp + Vector2(-TILE_W/2,0), sp + Vector2(0,-TILE_H/2)]), Color(0.55,0.43,0.68,0.12), 1.0)
    # pillars / obstacles
    for o in obstacles:
        var sp := _iso(o) + cam
        _draw_pillar(sp)
    for d in drops:
        var sp := _iso(d.pos) + cam
        var glow := Color("#f2bd55") if d.kind == "gold" else Color("#b98aff")
        draw_circle(sp + Vector2(0, -7), 12 + sin(elapsed * 5) * 2, Color(glow.r, glow.g, glow.b, 0.15))
        draw_colored_polygon(PackedVector2Array([sp+Vector2(0,-12),sp+Vector2(9,-5),sp+Vector2(0,2),sp+Vector2(-9,-5)]), glow)
    # depth sort enemies and player
    var drawables: Array[Dictionary] = []
    for e in enemies: drawables.append({"pos": e.pos, "kind": "enemy", "data": e})
    drawables.append({"pos": player, "kind": "player", "data": {}})
    drawables.sort_custom(func(a,b): return a.pos.y < b.pos.y)
    for item in drawables:
        var sp := _iso(item.pos) + cam
        if item.kind == "player": _draw_player(sp)
        else: _draw_enemy(sp, item.data)
    for p in particles:
        var sp := _iso(p.pos) + cam
        var alpha := clampf(p.life / p.max, 0.0, 1.0)
        draw_circle(sp, 3.5 * alpha, Color(p.color.r, p.color.g, p.color.b, alpha))
    # exit rune
    var exit_sp := _iso(Vector2(420, 220)) + cam
    draw_circle(exit_sp, 24, Color(0.48,0.2,0.85,0.16))
    draw_arc(exit_sp, 19, elapsed, elapsed + PI * 1.5, 32, Color("#a978ef"), 2.0)

func _draw_pillar(p: Vector2) -> void:
    draw_colored_polygon(PackedVector2Array([p+Vector2(-17,-3),p+Vector2(0,-13),p+Vector2(17,-3),p+Vector2(0,7)]), Color("#493b59"))
    draw_rect(Rect2(p.x-14,p.y-55,28,52), Color("#30263c"))
    draw_colored_polygon(PackedVector2Array([p+Vector2(-14,-55),p+Vector2(0,-65),p+Vector2(14,-55),p+Vector2(0,-45)]), Color("#77618b"))
    draw_line(p+Vector2(-14,-54),p+Vector2(-14,-5),Color("#a28bb8",0.35),2)

func _draw_player(p: Vector2) -> void:
    var bob := sin(elapsed * 8) * 2.0
    draw_ellipse(p + Vector2(0, 2), Vector2(20, 9), Color(0,0,0,0.38))
    draw_colored_polygon(PackedVector2Array([p+Vector2(-13,-12+bob),p+Vector2(0,-20+bob),p+Vector2(14,-12+bob),p+Vector2(0,-4+bob)]), Color("#6b3f93"))
    draw_rect(Rect2(p.x-10,p.y-38+bob,20,24), Color("#342743"))
    draw_rect(Rect2(p.x-8,p.y-49+bob,16,15), Color("#d1b8a0"))
    draw_colored_polygon(PackedVector2Array([p+Vector2(-10,-49+bob),p+Vector2(0,-61+bob),p+Vector2(10,-49+bob),p+Vector2(8,-45+bob),p+Vector2(-8,-45+bob)]), Color("#24182f"))
    draw_rect(Rect2(p.x-7,p.y-45+bob,14,3), Color("#a98bce"))
    var weapon_end := p + Vector2(23,-32) + facing * 14.0
    draw_line(p+Vector2(9,-27), weapon_end, Color("#e3d8f3"), 4)
    draw_line(p+Vector2(9,-27), weapon_end, Color("#8e65c5"), 1)
    if attack_anim > 0:
        draw_arc(p+Vector2(0,-25), 42, -1.4 + attack_anim*3, 1.1 + attack_anim*3, 24, Color(0.85,0.72,1,0.8), 5)
    if skill_anim > 0:
        draw_arc(p+Vector2(0,-12), 75 + (0.5-skill_anim)*120, 0, TAU, 40, Color(0.66,0.32,1,0.65), 4)

func _draw_enemy(p: Vector2, e: Dictionary) -> void:
    var boss: bool = e.boss
    var scale := 1.7 if boss else 1.0
    var bob := sin(e.anim * 5) * 2
    var col := Color("#b23d69") if boss else Color("#634d75")
    if e.flash > 0: col = Color("#f6eaff")
    draw_ellipse(p + Vector2(0, 3), Vector2(22*scale, 9*scale), Color(0,0,0,0.4))
    draw_colored_polygon(PackedVector2Array([p+Vector2(-15*scale,-12*scale+bob),p+Vector2(0,-35*scale+bob),p+Vector2(15*scale,-12*scale+bob),p+Vector2(0,-4*scale+bob)]), col)
    draw_circle(p+Vector2(0,-39*scale+bob), 11*scale, Color("#292034") if not boss else Color("#4d203b"))
    draw_circle(p+Vector2(-4*scale,-40*scale+bob), 2.5*scale, Color("#e8a9ff"))
    draw_circle(p+Vector2(4*scale,-40*scale+bob), 2.5*scale, Color("#e8a9ff"))
    if boss:
        draw_arc(p+Vector2(0,-30), 34, 0, TAU, 32, Color("#b84dba",0.7), 3)
    var bar_w := 44.0 if not boss else 92.0
    draw_rect(Rect2(p.x-bar_w/2,p.y-62*scale,bar_w,4), Color("#241c2b"))
    draw_rect(Rect2(p.x-bar_w/2,p.y-62*scale,bar_w*maxf(0,e.hp/e.max_hp),4), Color("#d34a68"))

func _draw_hud() -> void:
    _panel(Rect2(16, 14, 250, 72), Color(0.07,0.05,0.1,0.88))
    draw_string(ThemeDB.fallback_font, Vector2(30, 38), "RIFTWALKER  •  LV %d" % player_level, HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color("#e9ddff"))
    draw_rect(Rect2(30, 48, 215, 12), Color("#332337"))
    draw_rect(Rect2(30, 48, 215 * player_hp/player_max_hp, 12), Color("#c44966"))
    draw_string(ThemeDB.fallback_font, Vector2(30, 77), "HP  %d / %d" % [int(player_hp), int(player_max_hp)], HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#cbb8d8"))
    _panel(Rect2(700, 14, 245, 70), Color(0.07,0.05,0.1,0.88))
    draw_string(ThemeDB.fallback_font, Vector2(715, 39), mode_names[mode] + "  •  " + map_names[map_index], HORIZONTAL_ALIGNMENT_LEFT, 220, 12, Color("#e9ddff"))
    draw_string(ThemeDB.fallback_font, Vector2(715, 65), "FLOOR %d   WAVE %d   GOLD %d" % [floor_no,wave_no,player_gold], HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color("#eacb7b"))
    # mobile controls
    draw_circle(Vector2(120, 425), 57, Color(0.1,0.08,0.16,0.55))
    draw_circle(Vector2(120, 425), 24, Color(0.6,0.45,0.78,0.2))
    draw_circle(Vector2(120, 425) + joystick_vec*32, 19, Color("#a98bd0"))
    _control_button(Vector2(865, 435), 55, "ATK", Color("#8e5ab0"))
    _control_button(Vector2(720, 455), 42, "SKILL", Color("#6845a1"))
    _control_button(Vector2(610, 465), 36, "DASH", Color("#4a668c"))
    _panel(Rect2(888, 12, 55, 43), Color("#382848"))
    _center_text("Ⅱ", Vector2(915, 41), 22, Color("#eee5ff"))
    if combo > 1:
        _center_text("%d HIT COMBO" % combo, Vector2(480, 160), 20, Color("#f0d5ff"))

func _draw_pause() -> void:
    draw_rect(Rect2(0,0,W,H), Color(0,0,0,0.65))
    _panel(Rect2(300, 150, 360, 310), Color("#21182e"))
    _center_text("PAUSED", Vector2(480, 205), 32, Color("#eee5ff"))
    _draw_button(Rect2(330, 240, 300, 58), "RESUME", true)
    _draw_button(Rect2(330, 310, 300, 58), "CHANGE MODE", false)
    _draw_button(Rect2(330, 380, 300, 58), "MAIN MENU", false)

func _draw_game_over() -> void:
    _draw_backdrop()
    _center_text("DESCENT ENDED", Vector2(480, 150), 38, Color("#e9ddff"))
    _center_text("LEVEL %d     KILLS %d     GOLD %d" % [player_level,kills,player_gold], Vector2(480, 220), 17, Color("#d2c0e8"))
    _center_text("BEST ENDLESS: %d" % best_endless, Vector2(480, 255), 15, Color("#d9b76f"))
    _draw_button(Rect2(330, 320, 300, 60), "CHOOSE ANOTHER MODE", true)
    _draw_button(Rect2(330, 390, 300, 60), "MAIN MENU", false)

func _draw_backdrop() -> void:
    for i in range(12):
        var x := float(i) * 100
        draw_line(Vector2(x,0), Vector2(x-260,540), Color(0.45,0.25,0.62,0.08), 1)
    for i in range(8):
        var r := 80.0 + i * 44.0
        draw_arc(Vector2(480,280), r, 0, TAU, 64, Color(0.48,0.24,0.72,0.055), 2)
    draw_circle(Vector2(480,270), 120, Color(0.42,0.18,0.7,0.06))

func _panel(rect: Rect2, color: Color) -> void:
    draw_rect(rect, color)
    draw_rect(rect, Color(0.68,0.52,0.84,0.35), false, 1.5)

func _draw_button(rect: Rect2, label: String, primary: bool) -> void:
    var c := Color("#573c72") if primary else Color("#292236")
    _panel(rect, c)
    _center_text(label, rect.position + Vector2(rect.size.x/2, rect.size.y/2 + 6), 16, Color("#f0e8ff"))

func _control_button(pos: Vector2, radius: float, label: String, color: Color) -> void:
    draw_circle(pos, radius, Color(color.r,color.g,color.b,0.65))
    draw_arc(pos, radius, 0, TAU, 32, Color(0.9,0.82,1,0.65), 2)
    _center_text(label, pos + Vector2(0,5), 11, Color("#ffffff"))

func _center_text(s: String, pos: Vector2, size: int, color: Color) -> void:
    var font := ThemeDB.fallback_font
    var width := font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
    draw_string(font, Vector2(pos.x - width/2, pos.y), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, color)

func draw_ellipse(pos: Vector2, radius: Vector2, color: Color) -> void:
    var points := PackedVector2Array()
    for i in range(24):
        var a := TAU * float(i) / 24.0
        points.append(pos + Vector2(cos(a)*radius.x, sin(a)*radius.y))
    draw_colored_polygon(points, color)

func _save() -> void:
    var cfg := ConfigFile.new()
    cfg.set_value("player", "level", player_level)
    cfg.set_value("player", "gold", player_gold)
    cfg.set_value("player", "weapon_power", weapon_power)
    cfg.set_value("player", "armor", armor)
    cfg.set_value("records", "best_endless", best_endless)
    cfg.set_value("settings", "sound_enabled", sound_enabled)
    cfg.set_value("settings", "music_enabled", music_enabled)
    cfg.save(SAVE_PATH)

func _load_save() -> void:
    var cfg := ConfigFile.new()
    if cfg.load(SAVE_PATH) == OK:
        player_level = int(cfg.get_value("player","level",1))
        player_gold = int(cfg.get_value("player","gold",0))
        weapon_power = float(cfg.get_value("player","weapon_power",16.0))
        armor = float(cfg.get_value("player","armor",0.0))
        best_endless = int(cfg.get_value("records","best_endless",0))
        sound_enabled = bool(cfg.get_value("settings","sound_enabled",true))
        music_enabled = bool(cfg.get_value("settings","music_enabled",true))
