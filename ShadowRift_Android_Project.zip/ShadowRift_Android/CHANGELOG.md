# Shadow Rift 2.0 — 2.5D Rebuild
- Rebased the game on Godot 4 with an isometric 2.5D renderer.
- Added mobile touch controls and desktop keyboard controls.
- Added Story, Dungeon, Endless and Boss Rush mode selection.
- Added six visual region palettes, enemy AI, boss encounters, combat combo, dash and area skill.
- Added XP, leveling, gold/shard drops, armory upgrade and local save.
- Added original synthesized sound effects.
