# Shadow Rift 2.5D — Godot Rebuild (v2.0 prototype)

This is a new Godot 4 project, not an Android APK. It replaces the old Kotlin Canvas prototype with a dedicated 2.5D/isometric game foundation.

## Included in this build
- Isometric tile-floor rendering with depth-sorted player and enemies
- Touch joystick and touch buttons for Android
- Keyboard controls for desktop testing (WASD / arrows, Space attack, Q skill, E dash)
- Four selectable modes: Story, Dungeon, Endless, Boss Rush
- Six region palettes, enemy chasing/attacks, boss encounters
- Three-hit combo, Shadow Nova area skill, dash, health, XP, level-up
- Gold and shadow-shard drops, persistent player stats and Endless record
- Original generated SFX: slash, hit, magic, loot, level-up
- Character/Armory screen with weapon upgrade

## Requirements
- Godot Engine 4.3 or newer
- Android export templates installed in Godot
- Android SDK/JDK configured in Editor Settings for APK export

## Run on PC
1. Open Godot 4.
2. Import this folder by selecting `project.godot`.
3. Press F6/F5 to run.

## Export Android APK
1. In Godot, install matching export templates: Editor > Manage Export Templates.
2. Install/configure Android SDK and JDK (Godot documentation: Android export).
3. Project > Export > Add Android preset.
4. Set package name to `com.shadowrift.game`.
5. Enable arm64-v8a (and optionally armeabi-v7a).
6. Export Project to create the APK.

## Controls
- PC: WASD/arrow keys move, Space attack, Q Shadow Nova, E dash, Esc pause.
- Android: left-side virtual joystick; right-side ATK, SKILL, DASH; top-right pause.

## Current prototype limitations
This is the first playable 2.5D foundation. Art is currently drawn procedurally in GDScript rather than a finished HD sprite/3D asset pack. Music, multiplayer, full quest dialogue, merchant/equipment drops, and handcrafted dungeon layouts are planned for later milestones. The game has not been exported or device-tested in this environment.

## Roadmap
- v2.0: 2.5D core, combat loop, touch controls, modes, drops, save data.
- v2.1: Handcrafted room chains, minimap, chests, keys, secret rooms, quest markers.
- v2.2: HD character/enemy sprite sheets, 8-direction animation, weapon classes and artifact slots.
- v2.3: Equipment rarity, randomized affixes, blacksmith, merchants, boss mechanics.
- v2.4: Music, ambience, more SFX, accessibility and performance pass.
