# Shadow Rift — Android Offline Action RPG

Current release: **V1.1**

## Release progression
- **V1.0.1:** stability patch — lifecycle pause/resume handling, safer save loading, persistent save on pause, and touch-state reset. These fixes are included in the V1.1 source.
- **V1.1:** combat and visual update — distinct top-down enemy silhouettes, improved player sprite, melee slash arc, combo/dash/Shadow Nova combat loop, ranged enemy projectiles, boss phases, and persistent armory upgrades.

## Build APK using your existing GitHub repository
If your repository already has the workflow that extracts `ShadowRift_Android_Project.zip`:
1. Upload this archive to the repository and name it exactly `ShadowRift_Android_Project.zip` (replace the old archive).
2. Keep the existing workflow's extract step: `unzip ShadowRift_Android_Project.zip` followed by `cp -r ShadowRift_Android/. .`.
3. Open **Actions** → **Build Shadow Rift APK** → **Run workflow**.
4. Open the successful run and download the APK artifact.

## Build APK in a clean repository
1. Extract this ZIP on your device. Open the `ShadowRift_Android` folder.
2. Upload the *contents inside that folder* to the root of your GitHub repository. Do not upload the parent folder itself.
3. Keep `.github/workflows/build-apk.yml` at the repository root.
4. Open **Actions** → **Build Shadow Rift V1.1 APK** → **Run workflow**.
5. Download artifact **ShadowRift-V1.1-APK**, extract it, and install `app-debug.apk`.

## Build requirements
JDK 17, Android Gradle Plugin 8.7.3, Gradle 8.9, Android SDK 35.

Package: `com.shadowrift.game` · Min Android: 6.0 (API 23) · Landscape · Offline.
