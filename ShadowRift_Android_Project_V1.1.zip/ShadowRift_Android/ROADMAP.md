# Shadow Rift roadmap

- V1.0.1 — stability patch (included in V1.1).
- V1.1 — combat and visual update (current).
- V1.2 — progression: unlockable skills, expanded equipment, boss rewards, long-term player progression.
- V1.3 — world: additional arenas, environmental hazards, map events.
- V2.0 — major overhaul: deeper builds, multi-phase bosses, quest progression, and expanded combat systems.

The project is top-down, dark-fantasy HD in direction, and gameplay-first. New content should not be added at the cost of touch responsiveness or stable frame pacing.
