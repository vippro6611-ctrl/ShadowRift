# Shadow Rift V1.0.1 — Stability Patch

- Save player upgrades and settings when the app moves to the background.
- Pause the run when Android backgrounds the app; resume without a large frame-time jump.
- Clear touch pointer state when pausing to prevent stuck movement or attack input.
- Clamp loaded save values to safe ranges so corrupted preference values cannot create invalid upgrade ranks or negative totals.
- Keep the display awake while a run is active.

This patch is incorporated into V1.1; it is not a separate APK target in this source bundle.
