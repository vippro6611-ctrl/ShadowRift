# Shadow Rift V1.1 — Combat & Visual Update

## Visuals
- Reworked the player into a layered top-down silhouette with cloak, glow, and directional weapon.
- Added a directional melee slash arc to make successful attacks readable.
- Reworked enemy silhouettes: standard, fast, tank, ranged, and boss enemies have distinct shapes and color identities.
- Improved enemy shadows, glow, health bars, and boss phase ring.

## Gameplay carried forward and refined
- Combo attacks with escalating damage.
- Shadow Nova area skill and cooldown display.
- Dash with brief invulnerability.
- Ranged enemy projectiles and multi-phase boss pressure.
- Level-up choices, gold rewards, and permanent armory upgrades.

## Stability
- Includes all V1.0.1 lifecycle, save-data, and touch-state fixes.


Android package versionCode is 21 so this build can update the previously shared V2.0 test APK (versionCode 20) without requiring an uninstall. The displayed release version remains V1.1.
